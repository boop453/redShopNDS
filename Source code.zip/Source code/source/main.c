#include <3ds.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <malloc.h>
#include <math.h>
#include <curl/curl.h>
#include <citro2d.h>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#define STBI_ONLY_PNG
#define STBI_ONLY_JPEG
#include "stb_image.h"

#include "top_bg_t3x.h"
#include "bottom_bg_t3x.h"
#include "sprites_top_t3x.h"
#include "sprites_bot_t3x.h"
#include "loupe_t3x.h"
#include "gear_t3x.h"

#define NUM_BAGS_TOP  3
#define NUM_BAGS_BOT  3

typedef struct {
    float ox, oy;
    float angle;
    float scale;
    float phase_y;
    float phase_x;
    float phase_r;
    int   spriteIdx;
} BagSprite;

static C2D_SpriteSheet bags_top_sheet;
static C2D_SpriteSheet bags_bot_sheet;
static BagSprite bags_top[NUM_BAGS_TOP];
static BagSprite bags_bot[NUM_BAGS_BOT];
static float     anim_timer = 0.0f;

static void anim_init_bags_top(void) {

    BagSprite init[NUM_BAGS_TOP] = {

        {  66,  72,  -0.35f,  0.90f,   0.0f,    1.0f,    2.0f,   0 },
        { 338,  35,  -0.18f,  0.58f,   2.1f,    3.0f,    0.5f,   1 },
        { 334, 210,   0.12f,  0.55f,   4.3f,    5.0f,    3.5f,   2 },
    };
    for (int i = 0; i < NUM_BAGS_TOP; i++) bags_top[i] = init[i];
}

static void anim_init_bags_bot(void) {

    BagSprite init[NUM_BAGS_BOT] = {

        {  36,  44,  -0.35f,  0.52f,   1.5f,    2.5f,    4.0f,   0 },
        {  37, 185,   0.25f,  0.80f,   3.2f,    0.8f,    1.2f,   1 },
        { 270, 158,   0.02f,  0.85f,   0.7f,    4.2f,    2.8f,   2 },
    };
    for (int i = 0; i < NUM_BAGS_BOT; i++) bags_bot[i] = init[i];
}

static void anim_update(void) {
    anim_timer += 0.016f;
}

static void anim_draw_bags(C2D_SpriteSheet ss, BagSprite *bags, int n) {
    C2D_Sprite spr;
    for (int i = 0; i < n; i++) {
        BagSprite *b = &bags[i];
        float dx = sinf(anim_timer * 0.5f + b->phase_x) * 2.5f;
        float dy = sinf(anim_timer * 0.7f + b->phase_y) * 3.5f;
        float dr = sinf(anim_timer * 0.3f + b->phase_r) * 0.04f;
        C2D_SpriteFromSheet(&spr, ss, (size_t)b->spriteIdx);
        C2D_SpriteSetCenter(&spr, 0.5f, 0.5f);
        C2D_SpriteSetPos(&spr, b->ox + dx, b->oy + dy);
        C2D_SpriteSetRotation(&spr, b->angle + dr);
        C2D_SpriteSetScale(&spr, b->scale, b->scale);
        C2D_DrawSprite(&spr);
    }
}

#define SOC_ALIGN       0x1000
#define SOC_BUFFERSIZE  0x100000

static u32 *SOC_buffer = NULL;

#define API_HOST "my ip"
#define API_PATH "/api/titles"
#define MAX_TITLES 100
#define JSON_BUFFER_SIZE 65536

typedef struct {
    char name[128];
    char id[32];
    char url[256];
    char icon_url[256];
    char size[32];
    int size_mb;
    char platform[16];
    bool is_compatible;
    int region_class; 
} Title;

Title titles[MAX_TITLES];
int title_count = 0;
int selected_index = 0;
int scroll_offset = 0;
bool download_cancelled = false;
bool download_in_progress = false;
char download_status[128] = "";

typedef enum { STATE_MENU = 0, STATE_GAMES, STATE_SETTINGS, STATE_MANUAL } AppState;
static AppState app_state = STATE_MENU;
static int menu_selected = 0;
static int manual_scroll = 0;
static int settings_sel  = 0;
static int settings_sort = 0; 
static int settings_region = 0; 
static int settings_lang = 1;
static int settings_filter = 0;

#define LANG_COUNT 10
static const char* LANG_NAMES[LANG_COUNT] = {
    "Français",    "English",   "Italiano",  "Deutsch",
    "Nederlands",  "Español",   "Português", "Polski",
    "\u0420\u0443\u0441\u0441\u043a\u0438\u0439",
    "\u0421\u0440\u043f\u0441\u043a\u0438",
};

typedef enum {
    STR_ALL=0, STR_NDS_ONLY, STR_GBA_ONLY,
    STR_LANGUAGE, STR_FILTER, STR_BACK,
    STR_SETTINGS_TITLE, STR_MANUAL_TITLE,
    STR_NO_RESULTS, STR_DOWNLOADING,
    STR_HOLD_B_CANCEL, STR_ERROR, STR_CANNOT_CREATE,
    STR_LOADING, STR_NO_GAME, STR_GAME_DETAILS,
    STR_MAIN_MENU, STR_GAMES, STR_SETTINGS_MENU, STR_MANUAL_MENU,
    STR_SEARCH_BTN, STR_OK_CANCEL, STR_SELECT,
    STR_SORT_LABEL, STR_SORT_OFF, STR_SORT_ALPHA, STR_SORT_SIZE,
    STR_NOT_ENOUGH_SPACE, STR_DOWNLOAD_FAILED_MSG,
    STR_REGION_LABEL, STR_REGION_USA, STR_REGION_EUROPE, STR_REGION_OTHER,
    STR_DOWNLOAD_FOLDER_LABEL, STR_DOWNLOAD_SUCCESS_TIP,
    STR_COUNT
} StrID;

static const char* STRINGS[LANG_COUNT][STR_COUNT] = {
  {"Tous","NDS seul.","GBA seul.","Langue","Plateforme","B: Retour",
   "Param\u00e8tres","Manuel","Aucun r\u00e9sultat","T\u00e9l\u00e9chargement...",
   "B: Annuler","ERREUR","Impossible de cr\u00e9er le fichier",
   "Chargement...","Aucun jeu s\u00e9lectionn\u00e9","D\u00e9tails du jeu",
   "Menu principal","Jeux","Param\u00e8tres","Manuel",
   "Chercher","A: OK  B: Annuler","A: S\u00e9lectionner",
   "Filtres","D\u00e9sactiv\u00e9","Alphab\u00e9tique","Taille",
   "Espace insuffisant sur la carte SD",
   "\u00c9chec du t\u00e9l\u00e9chargement. V\u00e9rifiez votre connexion internet et r\u00e9essayez.",
   "Région","USA","Europe","Autres",
   "Dossier de t\u00e9l\u00e9chargement","Utilisez TWiLight Menu++ pour\ny jouer, ou ajoutez vos jeux\nDS au menu avec NDS Forwarder\nGenerator."},
  {"All","NDS only","GBA only","Language","Platform","B: Back",
   "Settings","User Manual","No results","Downloading...",
   "B: Cancel","ERROR","Cannot create file",
   "Loading...","No game selected","Game Details",
   "Main Menu","Games","Settings","Manual",
   "Search","A: OK  B: Cancel","A: Select",
   "Sort","Disabled","Alphabetical","Size",
   "Not enough space on SD card",
   "Download failed. Check your internet connection and try again.",
   "Region","USA","Europe","Other",
   "Download Folder","Use TWiLight Menu++ to play\nit, or add your DS games to\nthe menu with NDS Forwarder\nGenerator."},
  {"Tutti","Solo NDS","Solo GBA","Lingua","Piattaforma","B: Indietro",
   "Impostazioni","Manuale","Nessun risultato","Scaricamento...",
   "B: Annulla","ERRORE","Impossibile creare il file",
   "Caricamento...","Nessun gioco selezionato","Dettagli gioco",
   "Menu principale","Giochi","Impostazioni","Manuale",
   "Cerca","A: OK  B: Annulla","A: Seleziona",
   "Ordina","Disattivato","Alfabetico","Dimensione",
   "Spazio insufficiente sulla scheda SD",
   "Download non riuscito. Controlla la connessione a internet e riprova.",
   "Regione","USA","Europa","Altro",
   "Cartella di download","Usa TWiLight Menu++ per\ngiocarci, oppure aggiungi i\ntuoi giochi DS al menu con NDS\nForwarder Generator."},
  {"Alle","Nur NDS","Nur GBA","Sprache","Plattform","B: Zur\u00fcck",
   "Einstellungen","Handbuch","Kein Ergebnis","Herunterladen...",
   "B: Abbrechen","FEHLER","Datei konnte nicht erstellt werden",
   "Laden...","Kein Spiel ausgew\u00e4hlt","Spieldetails",
   "Hauptmen\u00fc","Spiele","Einstellungen","Handbuch",
   "Suchen","A: OK  B: Abbrechen","A: Ausw\u00e4hlen",
   "Sortieren","Deaktiviert","Alphabetisch","Gr\u00f6\u00dfe",
   "Nicht genug Speicherplatz auf der SD-Karte",
   "Download fehlgeschlagen. \u00dcberpr\u00fcfe deine Internetverbindung und versuche es erneut.",
   "Region","USA","Europa","Andere",
   "Download-Ordner","Nutze TWiLight Menu++ zum\nSpielen, oder f\u00fcge deine\nDS-Spiele mit NDS Forwarder\nGenerator zum Men\u00fc hinzu."},
  {"Alle","Alleen NDS","Alleen GBA","Taal","Platform","B: Terug",
   "Instellingen","Handleiding","Geen resultaat","Downloaden...",
   "B: Annuleren","FOUT","Bestand kan niet worden aangemaakt",
   "Laden...","Geen spel geselecteerd","Speldetails",
   "Hoofdmenu","Spellen","Instellingen","Handleiding",
   "Zoeken","A: OK  B: Annuleren","A: Selecteren",
   "Sorteren","Uitgeschakeld","Alfabetisch","Grootte",
   "Onvoldoende ruimte op de SD-kaart",
   "Download mislukt. Controleer je internetverbinding en probeer opnieuw.",
   "Regio","VS","Europa","Overig",
   "Downloadmap","Gebruik TWiLight Menu++ om te\nspelen, of voeg je DS-spellen\ntoe aan het menu met NDS\nForwarder Generator."},
  {"Todos","Solo NDS","Solo GBA","Idioma","Plataforma","B: Volver",
   "Ajustes","Manual","Sin resultados","Descargando...",
   "B: Cancelar","ERROR","No se puede crear el archivo",
   "Cargando...","Ning\u00fan juego seleccionado","Detalles del juego",
   "Men\u00fa principal","Juegos","Ajustes","Manual",
   "Buscar","A: OK  B: Cancelar","A: Seleccionar",
   "Ordenar","Desactivado","Alfab\u00e9tico","Tama\u00f1o",
   "Espacio insuficiente en la tarjeta SD",
   "Descarga fallida. Comprueba tu conexi\u00f3n a internet e int\u00e9ntalo de nuevo.",
   "Región","USA","Europa","Otros",
   "Carpeta de descargas","Usa TWiLight Menu++ para\njugarlo, o a\u00f1ade tus juegos DS\nal men\u00fa con NDS Forwarder\nGenerator."},
  {"Todos","Apenas NDS","Apenas GBA","Idioma","Plataforma","B: Voltar",
   "Defini\u00e7\u00f5es","Manual","Sem resultados","Transferindo...",
   "B: Cancelar","ERRO","N\u00e3o foi poss\u00edvel criar o ficheiro",
   "A carregar...","Nenhum jogo selecionado","Detalhes do jogo",
   "Menu principal","Jogos","Defini\u00e7\u00f5es","Manual",
   "Pesquisar","A: OK  B: Cancelar","A: Selecionar",
   "Ordenar","Desativado","Alfab\u00e9tico","Tamanho",
   "Espa\u00e7o insuficiente no cart\u00e3o SD",
   "Falha na transfer\u00eancia. Verifique a sua liga\u00e7\u00e3o \u00e0 internet e tente novamente.",
   "Região","EUA","Europa","Outros",
   "Pasta de transfer\u00eancias","Use o TWiLight Menu++ para\njogar, ou adicione os seus\njogos DS ao menu com o NDS\nForwarder Generator."},
  {"Wszystkie","Tylko NDS","Tylko GBA","J\u0119zyk","Platforma","B: Wstecz",
   "Ustawienia","Podr\u0119cznik","Brak wynik\u00f3w","Pobieranie...",
   "B: Anuluj","B\u0141\u0104D","Nie mo\u017cna utworzy\u0107 pliku",
   "\u0141adowanie...","Nie wybrano gry","Szczeg\u00f3\u0142y gry",
   "G\u0142\u00f3wne menu","Gry","Ustawienia","Podr\u0119cznik",
   "Szukaj","A: OK  B: Anuluj","A: Wybierz",
   "Sortuj","Wy\u0142\u0105czone","Alfabetycznie","Rozmiar",
   "Za ma\u0142o miejsca na karcie SD",
   "Pobieranie nie powiod\u0142o si\u0119. Sprawd\u017a po\u0142\u0105czenie internetowe i spr\u00f3buj ponownie.",
   "Region","USA","Europa","Inne",
   "Folder pobierania","U\u017cyj TWiLight Menu++, aby\nzagra\u0107, lub dodaj swoje gry DS\ndo menu za pomoc\u0105 NDS\nForwarder Generator."},
  {"\u0412\u0441\u0435","\u0422\u043e\u043b\u044c\u043a\u043e NDS","\u0422\u043e\u043b\u044c\u043a\u043e GBA","\u042f\u0437\u044b\u043a","\u041f\u043b\u0430\u0442\u0444\u043e\u0440\u043c\u0430","B: \u041d\u0430\u0437\u0430\u0434",
   "\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438","\u0420\u0443\u043a\u043e\u0432\u043e\u0434\u0441\u0442\u0432\u043e","\u041d\u0435\u0442 \u0440\u0435\u0437\u0443\u043b\u044c\u0442\u0430\u0442\u043e\u0432","\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430...",
   "B: \u041e\u0442\u043c\u0435\u043d\u0430","\u041e\u0428\u0418\u0411\u041a\u0410","\u041d\u0435\u0432\u043e\u0437\u043c\u043e\u0436\u043d\u043e \u0441\u043e\u0437\u0434\u0430\u0442\u044c \u0444\u0430\u0439\u043b",
   "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430...","\u0418\u0433\u0440\u0430 \u043d\u0435 \u0432\u044b\u0431\u0440\u0430\u043d\u0430","\u0421\u0432\u0435\u0434\u0435\u043d\u0438\u044f \u043e\u0431 \u0438\u0433\u0440\u0435",
   "\u0413\u043b\u0430\u0432\u043d\u043e\u0435 \u043c\u0435\u043d\u044e","\u0418\u0433\u0440\u044b","\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438","\u0420\u0443\u043a\u043e\u0432\u043e\u0434\u0441\u0442\u0432\u043e",
   "\u041f\u043e\u0438\u0441\u043a","A: OK  B: \u041e\u0442\u043c\u0435\u043d\u0430","A: \u0412\u044b\u0431\u0440\u0430\u0442\u044c",
   "\u0421\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u043a\u0430","\u041e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u043e","\u041f\u043e \u0430\u043b\u0444\u0430\u0432\u0438\u0442\u0443","\u041f\u043e \u0440\u0430\u0437\u043c\u0435\u0440\u0443",
   "\u041d\u0435\u0434\u043e\u0441\u0442\u0430\u0442\u043e\u0447\u043d\u043e \u043c\u0435\u0441\u0442\u0430 \u043d\u0430 SD-\u043a\u0430\u0440\u0442\u0435",
   "\u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043d\u0435 \u0443\u0434\u0430\u043b\u0430\u0441\u044c. \u041f\u0440\u043e\u0432\u0435\u0440\u044c\u0442\u0435 \u043f\u043e\u0434\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u043a \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442\u0443 \u0438 \u043f\u043e\u043f\u0440\u043e\u0431\u0443\u0439\u0442\u0435 \u0441\u043d\u043e\u0432\u0430.",
   "Регион","США","Европа","Другие",
   "\u041f\u0430\u043f\u043a\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u043e\u043a","\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 TWiLight Menu++,\n\u0447\u0442\u043e\u0431\u044b \u0438\u0433\u0440\u0430\u0442\u044c, \u0438\u043b\u0438 \u0434\u043e\u0431\u0430\u0432\u044c\u0442\u0435\n\u0441\u0432\u043e\u0438 DS-\u0438\u0433\u0440\u044b \u0432 \u043c\u0435\u043d\u044e \u0447\u0435\u0440\u0435\u0437 NDS\nForwarder Generator."},
  {"\u0421\u0432\u0435","\u0421\u0430\u043c\u043e NDS","\u0421\u0430\u043c\u043e GBA","J\u0435\u0437\u0438\u043a","\u041f\u043b\u0430\u0442\u0444\u043e\u0440\u043c\u0430","B: \u041d\u0430\u0437\u0430\u0434",
   "\u041f\u043e\u0434\u0435\u0448\u0430\u0432\u0430nj\u0430","\u041f\u0440\u0438\u0440\u0443\u0447\u043d\u0438\u043a","\u041d\u0435\u043c\u0430 \u0440\u0435\u0437\u0443\u043b\u0442\u0430\u0442\u0430","\u041f\u0440\u0435\u0443\u0437\u0438\u043c\u0430nj\u0435...",
   "B: \u041e\u0442\u043a\u0430\u0436\u0438","\u0413\u0420\u0415\u0428\u041a\u0410","\u041d\u0435 \u043c\u043e\u0433\u0443 \u0434\u0430 \u043d\u0430\u043f\u0440\u0430\u0432\u0438\u043c \u0444\u0430j\u043b",
   "\u0423\u0447\u0438\u0442\u0430\u0432\u0430nj\u0435...","\u041d\u0438j\u0435\u0434\u043d\u0430 \u0438\u0433\u0440\u0430 \u043d\u0438j\u0435 \u0438\u0437\u0430\u0431\u0440\u0430\u043d\u0430","\u0414\u0435\u0442\u0430lj\u0438 \u0438\u0433\u0440\u0435",
   "\u0413\u043b\u0430\u0432\u043d\u0438 \u043c\u0435\u043d\u0438","\u0418\u0433\u0440\u0435","\u041f\u043e\u0434\u0435\u0448\u0430\u0432\u0430nj\u0430","\u041f\u0440\u0438\u0440\u0443\u0447\u043d\u0438\u043a",
   "\u041f\u0440\u0435\u0442\u0440\u0430\u0433\u0430","A: OK  B: \u041e\u0442\u043a\u0430\u0436\u0438","A: \u0418\u0437\u0430\u0431\u0435\u0440\u0438",
   "\u0421\u043e\u0440\u0442\u0438\u0440\u0430nj\u0435","\u0418\u0441\u043aljучено","\u041f\u043e \u0430\u0437\u0431\u0443\u0446\u0438","\u041f\u043e \u0432\u0435\u043b\u0438\u0447\u0438\u043d\u0438",
   "\u041d\u0435\u0434\u043e\u0432\u043eljно \u043c\u0435\u0441\u0442\u0430 \u043d\u0430 SD \u043a\u0430\u0440\u0442\u0438\u0446\u0438",
   "\u041f\u0440\u0435\u0443\u0437\u0438\u043c\u0430nj\u0435 \u043d\u0438\u0458\u0435 \u0443\u0441\u043f\u0435\u043b\u043e. \u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u0435 \u0438\u043d\u0442\u0435\u0440\u043d\u0435\u0442 \u0432\u0435\u0437\u0443 \u0438 \u043f\u043e\u043a\u0443\u0448\u0430\u0458\u0442\u0435 \u043f\u043e\u043d\u043e\u0432\u043e.",
   "Регион","SAD","Европа","Остало",
   "Folder za preuzimanje","Koristite TWiLight Menu++ da\nigrate, ili dodajte svoje DS\nigre u meni pomo\u0107u NDS\nForwarder Generator-a."},

};
#define STR(id) STRINGS[settings_lang][(id)]

static bool lang_dropdown_open = false;
static int  lang_dropdown_scroll = 0;
static bool filter_dropdown_open = false;
static bool sort_dropdown_open = false;
static bool region_dropdown_open = false;
static bool folder_dropdown_open = false;
static int  settings_download_folder_idx = 0;

char search_query[64] = "";
char download_folder[48] = "";
int filtered_indices[MAX_TITLES];
int filtered_count = 0;

#define SEARCHBAR_X      4
#define SEARCHBAR_Y      4
#define SEARCHBAR_W    268
#define SEARCHBAR_H     22
#define SEARCHBAR_R      5

#define GEAR_SIZE       20
#define GEAR_X         (280 + (40 - GEAR_SIZE) / 2)
#define GEAR_Y         (SEARCHBAR_Y + (SEARCHBAR_H - GEAR_SIZE) / 2)
#define GEAR_W          GEAR_SIZE
#define GEAR_H          GEAR_SIZE

#define MAGNIFIER_X  SEARCHBAR_X
#define MAGNIFIER_Y  SEARCHBAR_Y
#define MAGNIFIER_W  SEARCHBAR_W
#define MAGNIFIER_H  SEARCHBAR_H

#define GEAR_TOUCH_X  280
#define GEAR_TOUCH_Y  0
#define GEAR_TOUCH_W  40
#define GEAR_TOUCH_H  30

C3D_RenderTarget* top_target;
C3D_RenderTarget* bottom_target;
C2D_SpriteSheet top_spritesheet;
C2D_SpriteSheet bottom_spritesheet;
C2D_SpriteSheet gear_spritesheet;
C2D_Sprite top_sprite;
C2D_Sprite bottom_sprite;

C2D_TextBuf dynamicBuf;
C2D_Text text[50];

ndspWaveBuf waveBuf;
s16* audioBuffer = NULL;
u32 audioSize = 0;
bool audio_loaded = false;

static void str_tolower(const char* src, char* dst, int max_len) {
    int i;
    for (i = 0; i < max_len - 1 && src[i]; i++) {
        char c = src[i];
        if (c >= 'A' && c <= 'Z') c += 32;
        dst[i] = c;
    }
    dst[i] = '\0';
}

void update_filtered_list(void) {
    filtered_count = 0;
    char query_low[64] = {0};
    if (search_query[0] != '\0')
        str_tolower(search_query, query_low, sizeof(query_low));

    for (int i = 0; i < title_count; i++) {

        if (settings_filter == 1 && strcmp(titles[i].platform, "NDS") != 0 &&
                                     strcmp(titles[i].platform, "NDSi") != 0) continue;
        if (settings_filter == 2 && strcmp(titles[i].platform, "GBA") != 0) continue;

        if (settings_region != 0) {
            int want = settings_region == 3 ? 0 : settings_region; 
            if (titles[i].region_class != want) continue;
        }

        if (query_low[0] != '\0') {
            char name_low[128];
            str_tolower(titles[i].name, name_low, sizeof(name_low));
            if (strstr(name_low, query_low) == NULL) continue;
        }

        filtered_indices[filtered_count++] = i;
    }

    
    
    if (settings_sort == 1) {
        for (int a = 1; a < filtered_count; a++) {
            int key = filtered_indices[a];
            char key_low[128];
            str_tolower(titles[key].name, key_low, sizeof(key_low));
            int b = a - 1;
            while (b >= 0) {
                char cur_low[128];
                str_tolower(titles[filtered_indices[b]].name, cur_low, sizeof(cur_low));
                if (strcmp(cur_low, key_low) <= 0) break;
                filtered_indices[b + 1] = filtered_indices[b];
                b--;
            }
            filtered_indices[b + 1] = key;
        }
    } else if (settings_sort == 2) {
        for (int a = 1; a < filtered_count; a++) {
            int key = filtered_indices[a];
            int b = a - 1;
            while (b >= 0 && titles[filtered_indices[b]].size_mb < titles[key].size_mb) {
                filtered_indices[b + 1] = filtered_indices[b];
                b--;
            }
            filtered_indices[b + 1] = key;
        }
    }

    selected_index = 0;
    scroll_offset  = 0;
}

void open_search_keyboard(void) {
    SwkbdState swkbd;
    char buf[64] = "";

    swkbdInit(&swkbd, SWKBD_TYPE_NORMAL, 2, 63);
    swkbdSetHintText(&swkbd, "Search game...");
    swkbdSetInitialText(&swkbd, search_query);
    swkbdSetButton(&swkbd, SWKBD_BUTTON_LEFT,  "Clear",  false);
    swkbdSetButton(&swkbd, SWKBD_BUTTON_RIGHT, STR(STR_SEARCH_BTN), true);
    swkbdSetFeatures(&swkbd, SWKBD_DEFAULT_QWERTY);

    SwkbdButton btn = swkbdInputText(&swkbd, buf, sizeof(buf));

    if (btn == SWKBD_BUTTON_LEFT) {
        search_query[0] = '\0';
    } else if (btn == SWKBD_BUTTON_RIGHT || btn == SWKBD_BUTTON_CONFIRM) {
        strncpy(search_query, buf, sizeof(search_query) - 1);
        search_query[sizeof(search_query) - 1] = '\0';
    }

    update_filtered_list();
}




static const char* DOWNLOAD_FOLDER_PATH[]    = { "", "roms/nds", "roms/gba", "roms/dsi" };
static const char* DOWNLOAD_FOLDER_DISPLAY[] = { "SD:/", "SD:/roms/nds", "SD:/roms/gba", "SD:/roms/dsi" };
#define DOWNLOAD_FOLDER_COUNT 4

void apply_download_folder(int idx) {
    if (idx < 0 || idx >= DOWNLOAD_FOLDER_COUNT) idx = 0;
    strncpy(download_folder, DOWNLOAD_FOLDER_PATH[idx], sizeof(download_folder) - 1);
    download_folder[sizeof(download_folder) - 1] = '\0';

    if (download_folder[0] != '\0') {
        
        
        char path[64] = "sdmc:/";
        char tmp[48];
        strncpy(tmp, download_folder, sizeof(tmp) - 1);
        tmp[sizeof(tmp) - 1] = '\0';
        char* seg = strtok(tmp, "/");
        while (seg) {
            strncat(path, seg, sizeof(path) - strlen(path) - 1);
            mkdir(path, 0777); 
            strncat(path, "/", sizeof(path) - strlen(path) - 1);
            seg = strtok(NULL, "/");
        }
    }
}

bool load_wav_file(const char* filepath) {
    FILE* file = fopen(filepath, "rb");
    if (!file) return false;

    char header[44];
    fread(header, 1, 44, file);

    if (strncmp(header, "RIFF", 4) != 0 || strncmp(header + 8, "WAVE", 4) != 0) {
        fclose(file);
        return false;
    }

    fseek(file, 0, SEEK_END);
    audioSize = ftell(file) - 44;
    fseek(file, 44, SEEK_SET);

    audioBuffer = (s16*)linearAlloc(audioSize);
    if (!audioBuffer) { fclose(file); return false; }

    fread(audioBuffer, 1, audioSize, file);
    fclose(file);

    DSP_FlushDataCache(audioBuffer, audioSize);

    memset(&waveBuf, 0, sizeof(waveBuf));
    waveBuf.data_vaddr = audioBuffer;
    waveBuf.nsamples   = audioSize / 4;
    waveBuf.looping    = true;
    waveBuf.status     = NDSP_WBUF_FREE;

    return true;
}

typedef struct {
    char  *data;
    size_t size;
} MemoryStruct;

size_t write_memory_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    MemoryStruct *mem = (MemoryStruct *)userp;

    char *ptr = realloc(mem->data, mem->size + realsize + 1);
    if (!ptr) return 0;

    mem->data = ptr;
    memcpy(&(mem->data[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->data[mem->size] = 0;
    return realsize;
}

typedef struct {
    FILE *file;
    u64   total_downloaded;
    u64   expected_size;
    void* dlqueue;    
    bool  disk_full;  
} DownloadInfo;

static u64 g_download_progress = 0;
static u64 g_download_total    = 0;


#define DLQ_SLOTS     6
#define DLQ_SLOT_SIZE (512 * 1024)

typedef struct {
    u8*    data;
    size_t len;
    volatile bool used;
} DLQueueSlot;

typedef struct {
    DLQueueSlot slots[DLQ_SLOTS];
    FILE* file;
    int head; 
    int tail; 
    volatile bool writer_error;
    volatile bool disk_full; 
    volatile bool stop;
} DLQueue;

static void dlqueue_writer_thread(void* arg) {
    DLQueue* q = (DLQueue*)arg;

    for (;;) {
        if (!q->slots[q->tail].used) {
            if (q->stop) break;
            svcSleepThread(500000LL); 
            continue;
        }
        DLQueueSlot* s = &q->slots[q->tail];
        errno = 0;
        if (fwrite(s->data, 1, s->len, q->file) != s->len) {
            q->writer_error = true;
            
            
            
            
            if (errno == ENOSPC) q->disk_full = true;
        }
        s->used = false;
        q->tail = (q->tail + 1) % DLQ_SLOTS;
    }
}



static void dlqueue_push(DLQueue* q, const u8* data, size_t len) {
    while (len > 0) {
        size_t n = len > DLQ_SLOT_SIZE ? DLQ_SLOT_SIZE : len;
        while (q->slots[q->head].used) {
            if (download_cancelled) return;
            svcSleepThread(500000LL);
        }
        memcpy(q->slots[q->head].data, data, n);
        q->slots[q->head].len  = n;
        q->slots[q->head].used = true;
        q->head = (q->head + 1) % DLQ_SLOTS;
        data += n;
        len  -= n;
    }
}

size_t write_file_callback(void *contents, size_t size, size_t nmemb, void *userp) {
    DownloadInfo *info = (DownloadInfo *)userp;

    hidScanInput();
    if (hidKeysHeld() & KEY_B) { download_cancelled = true; return 0; }

    size_t total = size * nmemb;
    if (info->dlqueue) {
        dlqueue_push((DLQueue*)info->dlqueue, (const u8*)contents, total);
    } else {
        
        
        
        errno = 0;
        size_t written = fwrite(contents, size, nmemb, info->file);
        if (written != nmemb && errno == ENOSPC) info->disk_full = true;
        total = written * size;
    }
    info->total_downloaded += total;
    g_download_progress = info->total_downloaded;
    g_download_total    = info->expected_size;
    return total / size; 
}







static bool token_is_eu_code(const char* tok) {
    static const char* codes[] = { "fr","de","it","es","nl", NULL };
    for (int i = 0; codes[i]; i++) if (strcmp(tok, codes[i]) == 0) return true;
    return false;
}

static int classify_region(const char* name) {
    char combined[192];
    int  clen = 0;
    combined[0] = '\0';

    const char* p = name;
    while (*p) {
        if (*p == '(') {
            const char* close = strchr(p, ')');
            if (!close) break;
            int seglen = (int)(close - p - 1);
            if (seglen > 0) {
                if (clen > 0 && clen < (int)sizeof(combined) - 2) combined[clen++] = ',';
                if (seglen > (int)sizeof(combined) - clen - 1) seglen = (int)sizeof(combined) - clen - 1;
                if (seglen > 0) {
                    memcpy(combined + clen, p + 1, seglen);
                    clen += seglen;
                    combined[clen] = '\0';
                }
            }
            p = close + 1;
        } else {
            p++;
        }
    }
    if (clen == 0) return 0;

    char low[192];
    str_tolower(combined, low, sizeof(low));

    if (strstr(low, "usa") || strstr(low, "world")) return 1;
    if (strstr(low, "europe") || strstr(low, "eur") ||
        strstr(low, "france") || strstr(low, "germany") ||
        strstr(low, "spain")  || strstr(low, "italy")   ||
        strstr(low, "netherlands")) return 2;

    
    
    
    char tokbuf[192];
    strncpy(tokbuf, low, sizeof(tokbuf) - 1);
    tokbuf[sizeof(tokbuf) - 1] = '\0';
    char* saveptr = NULL;
    char* tok = strtok_r(tokbuf, ", ", &saveptr);
    while (tok) {
        if (token_is_eu_code(tok)) return 2;
        tok = strtok_r(NULL, ", ", &saveptr);
    }

    return 0;
}

void parse_json_titles(char* json_data) {

    title_count = 0;
    char* ptr = json_data;

    ptr = strstr(ptr, "\"titles\"");
    if (!ptr) return;
    ptr = strchr(ptr, '[');
    if (!ptr) return;
    ptr++;

    while ((ptr = strchr(ptr, '{')) != NULL && title_count < MAX_TITLES) {
        ptr++;
        char* obj_end = strchr(ptr, '}');
        if (!obj_end) break;

        char* name_ptr = strstr(ptr, "\"name\"");
        if (name_ptr && name_ptr < obj_end) {
            name_ptr = strchr(name_ptr, ':');
            if (name_ptr) {
                name_ptr = strchr(name_ptr, '"');
                if (name_ptr) {
                    name_ptr++;
                    char* name_end = strchr(name_ptr, '"');
                    if (name_end && name_end < obj_end) {
                        int len = name_end - name_ptr;
                        if (len > 127) len = 127;
                        strncpy(titles[title_count].name, name_ptr, len);
                        titles[title_count].name[len] = '\0';
                        titles[title_count].region_class = classify_region(titles[title_count].name);
                    }
                }
            }
        }

        char* id_ptr = strstr(ptr, "\"id\"");
        if (id_ptr && id_ptr < obj_end) {
            id_ptr = strchr(id_ptr, ':');
            if (id_ptr) {
                id_ptr = strchr(id_ptr, '"');
                if (id_ptr) {
                    id_ptr++;
                    char* id_end = strchr(id_ptr, '"');
                    if (id_end && id_end < obj_end) {
                        int len = id_end - id_ptr;
                        if (len > 31) len = 31;
                        strncpy(titles[title_count].id, id_ptr, len);
                        titles[title_count].id[len] = '\0';
                    }
                }
            }
        }

        char* url_ptr = strstr(ptr, "\"url\"");
        if (url_ptr && url_ptr < obj_end) {
            url_ptr = strchr(url_ptr, ':');
            if (url_ptr) {
                url_ptr = strchr(url_ptr, '"');
                if (url_ptr) {
                    url_ptr++;
                    char* url_end = strchr(url_ptr, '"');
                    if (url_end && url_end < obj_end) {
                        int len = url_end - url_ptr;
                        if (len > 255) len = 255;
                        strncpy(titles[title_count].url, url_ptr, len);
                        titles[title_count].url[len] = '\0';
                    }
                }
            }
        }

        titles[title_count].icon_url[0] = '\0';
        char* icon_ptr = strstr(ptr, "\"icon\"");
        if (icon_ptr && icon_ptr < obj_end) {
            icon_ptr = strchr(icon_ptr, ':');
            if (icon_ptr) {
                icon_ptr = strchr(icon_ptr, '"');
                if (icon_ptr) {
                    icon_ptr++;
                    char* icon_end = strchr(icon_ptr, '"');
                    if (icon_end && icon_end < obj_end) {
                        int len = icon_end - icon_ptr;
                        if (len > 255) len = 255;
                        strncpy(titles[title_count].icon_url, icon_ptr, len);
                        titles[title_count].icon_url[len] = '\0';
                    }
                }
            }
        }

        titles[title_count].size_mb = 0;
        char* size_ptr = strstr(ptr, "\"size\"");
        if (size_ptr && size_ptr < obj_end) {
            size_ptr = strchr(size_ptr, ':');
            if (size_ptr) {
                size_ptr++;
                while (*size_ptr == ' ') size_ptr++;
                char size_buf[32];
                int i = 0;
                while (*size_ptr >= '0' && *size_ptr <= '9' && i < 31)
                    size_buf[i++] = *size_ptr++;
                size_buf[i] = '\0';
                long bytes = atol(size_buf);
                titles[title_count].size_mb = bytes / (1024 * 1024);
                snprintf(titles[title_count].size, 32, "%dMB", titles[title_count].size_mb);
            }
        } else {
            strcpy(titles[title_count].size, "?");
        }

        char* platform_ptr = strstr(ptr, "\"platform\"");
        if (platform_ptr && platform_ptr < obj_end) {
            platform_ptr = strchr(platform_ptr, ':');
            if (platform_ptr) {
                platform_ptr = strchr(platform_ptr, '"');
                if (platform_ptr) {
                    platform_ptr++;
                    char* platform_end = strchr(platform_ptr, '"');
                    if (platform_end && platform_end < obj_end) {
                        int len = platform_end - platform_ptr;
                        if (len > 15) len = 15;
                        strncpy(titles[title_count].platform, platform_ptr, len);
                        titles[title_count].platform[len] = '\0';
                    }
                }
            }
        } else {
            strcpy(titles[title_count].platform, "NDS");
        }

        titles[title_count].is_compatible = true;
        title_count++;
        ptr = obj_end;
    }
}

static void draw_rounded_rect(float x, float y, float w, float h, float r, float z, u32 color);

#define ICON_DIM        64
#define ICON_CACHE_MAX 100
#define ICON_WORKERS     8

typedef struct {
    int      title_idx;
    C3D_Tex  tex;
    bool     tex_inited;
    bool     ready;
    bool     pixels_ready;
    bool     loading;
    u8*      pixels_buf;
} IconSlot;

typedef struct {
    int  slot;
    int  title_idx;
    bool used;
} IconJob;

static IconSlot      icon_slots[ICON_CACHE_MAX];
static LightLock     icon_lock;
static Thread        icon_thread_handle = NULL;
static Thread        icon_workers[ICON_WORKERS];
static volatile bool icon_thread_run    = false;
static IconJob       icon_jobs[ICON_WORKERS];
static LightLock     icon_jobs_lock;

static void icon_system_init(void) {
    LightLock_Init(&icon_lock);
    LightLock_Init(&icon_jobs_lock);
    for (int i = 0; i < ICON_CACHE_MAX; i++) {
        icon_slots[i].title_idx    = -1;
        icon_slots[i].ready        = false;
        icon_slots[i].pixels_ready = false;
        icon_slots[i].pixels_buf   = NULL;
        icon_slots[i].tex_inited   = false;
        icon_slots[i].loading      = false;
        if (C3D_TexInit(&icon_slots[i].tex, ICON_DIM, ICON_DIM, GPU_RGBA8))
            icon_slots[i].tex_inited = true;
    }
    for (int i = 0; i < ICON_WORKERS; i++) {
        icon_jobs[i].used = false; icon_jobs[i].slot = -1;
        icon_jobs[i].title_idx = -1; icon_workers[i] = NULL;
    }
}

static void icon_system_free(void) {
    icon_thread_run = false;
    if (icon_thread_handle) { threadJoin(icon_thread_handle, U64_MAX); threadFree(icon_thread_handle); icon_thread_handle = NULL; }
    for (int i = 0; i < ICON_WORKERS; i++) {
        if (icon_workers[i]) { threadJoin(icon_workers[i], U64_MAX); threadFree(icon_workers[i]); icon_workers[i] = NULL; }
    }
    for (int i = 0; i < ICON_CACHE_MAX; i++) {
        if (icon_slots[i].pixels_buf) free(icon_slots[i].pixels_buf);
        if (icon_slots[i].tex_inited) C3D_TexDelete(&icon_slots[i].tex);
    }
}

static void icon_load_one(int slot, int title_idx) {
    if (titles[title_idx].icon_url[0] == '\0') return;
    LightLock_Lock(&icon_lock);
    if (icon_slots[slot].title_idx == title_idx) icon_slots[slot].loading = true;
    else { LightLock_Unlock(&icon_lock); return; }
    LightLock_Unlock(&icon_lock);

    MemoryStruct chunk;
    chunk.data = malloc(1);
    chunk.size = 0;

    CURL* curl = curl_easy_init();
    if (!curl) { free(chunk.data); return; }
    curl_easy_setopt(curl, CURLOPT_URL,            titles[title_idx].icon_url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,  write_memory_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,      (void*)&chunk);
    curl_easy_setopt(curl, CURLOPT_USERAGENT,      "3DS-hShop/1.0");
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,        5L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (chunk.size < 4) { free(chunk.data); return; }

    int w, h, ch;
    unsigned char* px = stbi_load_from_memory(
        (unsigned char*)chunk.data, (int)chunk.size, &w, &h, &ch, 4);
    free(chunk.data);
    if (!px) return;

    u8* buf = (u8*)malloc(ICON_DIM * ICON_DIM * 4);
    if (!buf) { stbi_image_free(px); return; }

    for (int y = 0; y < ICON_DIM; y++) {
        for (int x = 0; x < ICON_DIM; x++) {
            int sx = x * w / ICON_DIM;
            int sy = (ICON_DIM - 1 - y) * h / ICON_DIM;
            u8* src = px + (sy * w + sx) * 4;
            u8* dst = buf + (y * ICON_DIM + x) * 4;
            dst[0] = src[3] ? src[3] : 255;
            dst[1] = src[2];
            dst[2] = src[1];
            dst[3] = src[0];
        }
    }
    stbi_image_free(px);

    LightLock_Lock(&icon_lock);
    icon_slots[slot].loading = false;
    if (icon_slots[slot].tex_inited && icon_slots[slot].title_idx == title_idx) {
        if (icon_slots[slot].pixels_buf) free(icon_slots[slot].pixels_buf);
        icon_slots[slot].pixels_buf   = buf;
        icon_slots[slot].pixels_ready = true;
        buf = NULL;
    }
    LightLock_Unlock(&icon_lock);

    if (buf) free(buf);
}

static void icon_worker_func(void* arg) {
    int w = (int)(intptr_t)arg;
    while (icon_thread_run) {
        int slot = -1, ti = -1;
        LightLock_Lock(&icon_jobs_lock);
        if (icon_jobs[w].used) { slot = icon_jobs[w].slot; ti = icon_jobs[w].title_idx; }
        LightLock_Unlock(&icon_jobs_lock);
        if (slot >= 0 && ti >= 0) {
            icon_load_one(slot, ti);
            LightLock_Lock(&icon_jobs_lock); icon_jobs[w].used = false; LightLock_Unlock(&icon_jobs_lock);
        } else { svcSleepThread(10000000LL); }
    }
}

static void icon_request(int ti) {
    int slot = ti;
    if (slot < 0 || slot >= ICON_CACHE_MAX) return;

    LightLock_Lock(&icon_lock);
    bool already = icon_slots[slot].ready || icon_slots[slot].pixels_ready || icon_slots[slot].loading;
    if (!already && icon_slots[slot].title_idx == -1) {
        icon_slots[slot].title_idx    = ti;
        icon_slots[slot].ready        = false;
        icon_slots[slot].pixels_ready = false;
        icon_slots[slot].loading      = false;
    } else if (icon_slots[slot].title_idx == ti) {
        already = icon_slots[slot].ready;
    }
    LightLock_Unlock(&icon_lock);
    if (already) return;

    bool dispatched = false;
    while (!dispatched && icon_thread_run) {
        LightLock_Lock(&icon_jobs_lock);
        for (int w = 0; w < ICON_WORKERS; w++) {
            if (!icon_jobs[w].used) {
                icon_jobs[w].slot = slot; icon_jobs[w].title_idx = ti;
                icon_jobs[w].used = true; dispatched = true; break;
            }
        }
        LightLock_Unlock(&icon_jobs_lock);
        if (!dispatched) svcSleepThread(5000000LL);
    }
}

static void icon_thread_func(void* arg) {
    (void)arg;

    int last_center = -1;
    static int warmup_idx = 0;

    while (icon_thread_run) {
        
        
        
        
        
        if (download_in_progress) {
            svcSleepThread(100000000LL);
            continue;
        }

        int center = selected_index;

        if (center != last_center) {
            last_center = center;
            int order[17]; order[0] = 0;
            for (int k = 1; k <= 8; k++) { order[2*k-1]=-k; order[2*k]=k; }
            for (int o = 0; o < 17; o++) {
                if (!icon_thread_run) return;
                int li = center + order[o];
                if (li < 0 || li >= filtered_count) continue;
                icon_request(filtered_indices[li]);
            }
        }

        if (warmup_idx < filtered_count) {
            while (warmup_idx < filtered_count) {
                icon_request(filtered_indices[warmup_idx]);
                warmup_idx++;
            }
            svcSleepThread(500000000LL);
        } else {
            svcSleepThread(500000000LL);
        }
    }
}

static void icon_system_start(void) {
    icon_thread_run = true;
    for (int i = 0; i < ICON_WORKERS; i++)
        icon_workers[i] = threadCreate(icon_worker_func, (void*)(intptr_t)i, 64*1024, 0x3D, -1, false);
    icon_thread_handle = threadCreate(icon_thread_func, NULL, 32*1024, 0x3F, -1, false);
}

static void icon_gpu_flush(void) {
    for (int i = 0; i < ICON_CACHE_MAX; i++) {

        LightLock_Lock(&icon_lock);
        bool need = icon_slots[i].pixels_ready && !icon_slots[i].ready
                    && icon_slots[i].tex_inited && icon_slots[i].pixels_buf;
        u8* buf = NULL;
        if (need) {
            buf = icon_slots[i].pixels_buf;
            icon_slots[i].pixels_buf   = NULL;
            icon_slots[i].pixels_ready = false;
        }
        LightLock_Unlock(&icon_lock);
        if (!buf) continue;

        u8* lin = (u8*)linearAlloc(ICON_DIM * ICON_DIM * 4);
        if (!lin) { free(buf); continue; }
        memcpy(lin, buf, ICON_DIM * ICON_DIM * 4);
        free(buf);
        GSPGPU_FlushDataCache(lin, ICON_DIM * ICON_DIM * 4);

        C3D_SyncDisplayTransfer(
            (u32*)lin,                    GX_BUFFER_DIM(ICON_DIM, ICON_DIM),
            (u32*)icon_slots[i].tex.data, GX_BUFFER_DIM(ICON_DIM, ICON_DIM),
            GX_TRANSFER_FLIP_VERT(1) | GX_TRANSFER_OUT_TILED(1) |
            GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGBA8) |
            GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGBA8) |
            GX_TRANSFER_SCALING(GX_TRANSFER_SCALE_NO)
        );
        linearFree(lin);
        C3D_TexSetFilter(&icon_slots[i].tex, GPU_LINEAR, GPU_LINEAR);

        LightLock_Lock(&icon_lock);
        icon_slots[i].ready = true;
        LightLock_Unlock(&icon_lock);
    }
}

static void draw_icon(int title_idx, float x, float y, float size, bool selected) {
    LightLock_Lock(&icon_lock);
    C3D_Tex* tex = NULL;
    if (title_idx >= 0 && title_idx < ICON_CACHE_MAX &&
        icon_slots[title_idx].title_idx == title_idx && icon_slots[title_idx].ready)
        tex = &icon_slots[title_idx].tex;
    LightLock_Unlock(&icon_lock);

    if (tex) {
        static const Tex3DS_SubTexture sub = { ICON_DIM, ICON_DIM, 0.0f, 1.0f, 1.0f, 0.0f };
        C2D_Image img = { tex, &sub };
        float sc = size / (float)ICON_DIM;
        if (selected) {
            C2D_ImageTint t;
            C2D_PlainImageTint(&t, C2D_Color32(255,200,200,255), 0.3f);
            C2D_DrawImageAt(img, x, y, 0.5f, &t, sc, sc);
        } else {
            C2D_DrawImageAt(img, x, y, 0.5f, NULL, sc, sc);
        }
    } else {
        u32 ph = selected ? C2D_Color32(180,40,40,100) : C2D_Color32(60,60,60,80);
        draw_rounded_rect(x, y, size, size, 4, 0.35f, ph);
    }
}

char* http_get_json(void) {
    CURL *curl;
    CURLcode res;
    MemoryStruct chunk;

    chunk.data = malloc(1);
    chunk.size = 0;

    curl = curl_easy_init();
    if (!curl) { free(chunk.data); return NULL; }

    char url[512];
    snprintf(url, sizeof(url), "%s%s", API_HOST, API_PATH);

    curl_easy_setopt(curl, CURLOPT_URL,           url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_memory_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,     (void *)&chunk);
    curl_easy_setopt(curl, CURLOPT_USERAGENT,     "3DS-hShop/1.0");
    curl_easy_setopt(curl, CURLOPT_TIMEOUT,       30L);
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION,1L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER,0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST,0L);

    res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if (res != CURLE_OK) { free(chunk.data); return NULL; }
    return chunk.data;
}

int progress_callback(void *clientp, curl_off_t dltotal, curl_off_t dlnow, curl_off_t ultotal, curl_off_t ulnow) {
    (void)ultotal; (void)ulnow; (void)dltotal; (void)dlnow;

    hidScanInput();
    if (hidKeysHeld() & KEY_B) { download_cancelled = true; return 1; }

    
    
    
    
    
    
    
    static u64 last_draw_ms = 0;
    u64 now_ms = osGetTime();
    if (now_ms - last_draw_ms < 100) return 0;
    last_draw_ms = now_ms;

    C2D_TextBufClear(dynamicBuf);
    icon_gpu_flush();
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

    C2D_TargetClear(top_target, C2D_Color32(255, 255, 255, 255));
    C2D_SceneBegin(top_target);
    if (top_spritesheet) C2D_DrawSprite(&top_sprite);

    
    
    
    
    if (bags_top_sheet) anim_draw_bags(bags_top_sheet, bags_top, NUM_BAGS_TOP);

    int textIdx = 0;
    const char* game_name = (const char*)clientp;
    if (game_name) {

        float cx = 6.0f, cy = 85.0f, cw = 388.0f, ch = 46.0f;
        draw_rounded_rect(cx,     cy + 3, cw,     ch,     6, 0.27f, C2D_Color32(0, 0, 0, 50));
        draw_rounded_rect(cx - 1, cy - 1, cw + 2, ch + 2, 7, 0.28f, C2D_Color32(220, 0, 0, 120));
        draw_rounded_rect(cx,     cy,     cw,     ch,     6, 0.30f, C2D_Color32(255, 255, 255, 18));

        C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_DOWNLOADING));
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 201, cy + 6, 0.5f, 0.55f, 0.55f, C2D_Color32(255, 255, 255, 220));
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 200, cy + 5, 0.5f, 0.55f, 0.55f, C2D_Color32(255, 255, 255, 220));
        textIdx++;

        char short_name[40];
        strncpy(short_name, game_name, 37);
        short_name[37] = '\0';
        if (strlen(game_name) > 37) { short_name[34] = '.'; short_name[35] = '.'; short_name[36] = '.'; short_name[37] = '\0'; }
        C2D_TextParse(&text[textIdx], dynamicBuf, short_name);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, cx + 10.5f, cy + 19, 0.30f, 0.65f, 0.65f, C2D_Color32(255, 255, 255, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor, cx + 10.0f, cy + 18, 0.30f, 0.65f, 0.65f, C2D_Color32(255, 255, 255, 255));
        textIdx++;
    }

    C2D_TargetClear(bottom_target, C2D_Color32(255, 255, 255, 255));
    C2D_SceneBegin(bottom_target);
    if (bottom_spritesheet) C2D_DrawSprite(&bottom_sprite);
    if (bags_bot_sheet) anim_draw_bags(bags_bot_sheet, bags_bot, NUM_BAGS_BOT);
    
    

    float pc_x = 10.0f, pc_y = 50.0f, pc_w = 300.0f, pc_h = 130.0f, pc_r = 8.0f;
    draw_rounded_rect(pc_x + 2, pc_y + 3, pc_w, pc_h, pc_r, 0.38f, C2D_Color32(0, 0, 0, 18));
    draw_rounded_rect(pc_x - 1, pc_y - 1, pc_w + 2, pc_h + 2, pc_r + 1, 0.39f, C2D_Color32(220, 0, 0, 80));
    draw_rounded_rect(pc_x,     pc_y,     pc_w,     pc_h,     pc_r,     0.40f, C2D_Color32(255, 255, 255, 18));

    if (g_download_total > 0) {
        int percent = (int)((g_download_progress * 100LL) / g_download_total);
        if (percent > 100) percent = 100;
        if (percent < 0)   percent = 0;

        float bar_x = pc_x + 15.0f, bar_y = pc_y + 28.0f, bar_w = pc_w - 30.0f, bar_h = 18.0f;

        draw_rounded_rect(bar_x, bar_y, bar_w, bar_h, 4, 0.50f, C2D_Color32(255, 255, 255, 60));

        float fill_w = (bar_w * percent) / 100.0f;
        if (fill_w > 0) draw_rounded_rect(bar_x, bar_y, fill_w, bar_h, 4, 0.55f, C2D_Color32(255, 255, 255, 220));

        char percent_str[16];
        snprintf(percent_str, 16, "%d%%", percent);
        C2D_TextParse(&text[textIdx], dynamicBuf, percent_str);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 161, bar_y + bar_h + 5, 0.50f, 0.60f, 0.60f, C2D_Color32(255, 255, 255, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 160, bar_y + bar_h + 4, 0.50f, 0.60f, 0.60f, C2D_Color32(255, 255, 255, 255));
        textIdx++;

        char info_str[64];
        snprintf(info_str, 64, "%llu / %llu MB",
                 g_download_progress / (1024*1024),
                 g_download_total    / (1024*1024));
        C2D_TextParse(&text[textIdx], dynamicBuf, info_str);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 161, pc_y + 72, 0.50f, 0.52f, 0.52f, C2D_Color32(255, 255, 255, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 160, pc_y + 71, 0.50f, 0.52f, 0.52f, C2D_Color32(255, 255, 255, 255));
        textIdx++;
    }

    C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_HOLD_B_CANCEL));
    C2D_TextOptimize(&text[textIdx]);
    C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 161, pc_y + 96, 0.50f, 0.50f, 0.50f, C2D_Color32(255, 255, 255, 200));
    C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 160, pc_y + 95, 0.50f, 0.50f, 0.50f, C2D_Color32(255, 255, 255, 200));

    C3D_FrameEnd(0);
    return 0;
}



static void show_blocking_error_screen(const char* title, const char* subtitle) {
    while (aptMainLoop()) {
        hidScanInput();
        if (hidKeysDown() & KEY_A) break;

        C2D_TextBufClear(dynamicBuf);
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
        C2D_TargetClear(top_target, C2D_Color32(255, 255, 255, 255));
        C2D_SceneBegin(top_target);
        if (top_spritesheet) C2D_DrawSprite(&top_sprite);
        int textIdx = 0;
        C2D_TextParse(&text[textIdx], dynamicBuf, title);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, 160, 90, 0.5f, 0.7f, 0.7f, C2D_Color32(220, 0, 0, 255));
        textIdx++;
        C2D_TextParse(&text[textIdx], dynamicBuf, subtitle);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, 40, 120, 0.5f, 0.5f, 0.5f, C2D_Color32(255, 255, 255, 255));
        textIdx++;
        C2D_TextParse(&text[textIdx], dynamicBuf, "A: OK");
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 200, 160, 0.5f, 0.5f, 0.5f, C2D_Color32(180, 180, 180, 255));
        C2D_TargetClear(bottom_target, C2D_Color32(255, 255, 255, 255));
        C2D_SceneBegin(bottom_target);
        if (bottom_spritesheet) C2D_DrawSprite(&bottom_sprite);
        C3D_FrameEnd(0);
    }
}

void download_file_curl(const char* url_in, const char* filepath, long expected_size, int global_idx) {
    download_cancelled   = false;
    download_in_progress = true;
    g_download_progress  = 0;
    g_download_total     = expected_size;

    
    
    
    
    
    
    
    char url[512];
    if (strncmp(url_in, "https://", 8) == 0) {
        snprintf(url, sizeof(url), "http://%s", url_in + 8);
    } else {
        strncpy(url, url_in, sizeof(url) - 1);
        url[sizeof(url) - 1] = '\0';
    }

    
    
    
    
    
    
    
    
    
    
    
    
    FS_ArchiveResource resource;
    if (expected_size > 0 && R_SUCCEEDED(FSUSER_GetSdmcArchiveResource(&resource))) {
        u64 free_bytes = (u64)resource.freeClusters * (u64)resource.clusterSize;
        if (free_bytes < (u64)expected_size) {
            download_in_progress = false;
            show_blocking_error_screen(STR(STR_ERROR), STR(STR_NOT_ENOUGH_SPACE));
            return;
        }
    }

    FILE* file = fopen(filepath, "wb");
    if (!file) {
        download_in_progress = false;
        show_blocking_error_screen(STR(STR_ERROR), STR(STR_CANNOT_CREATE));
        return;
    }
    
    
    
    
    
    
    
    
    static char file_iobuf[DLQ_SLOT_SIZE];
    setvbuf(file, file_iobuf, _IOFBF, sizeof(file_iobuf));

    DownloadInfo info = { file, 0, (u64)expected_size, NULL, false };

    
    
    
    DLQueue* dlq = (DLQueue*)calloc(1, sizeof(DLQueue));
    Thread   writer_thread = NULL;
    if (dlq) {
        bool alloc_ok = true;
        for (int i = 0; i < DLQ_SLOTS; i++) {
            dlq->slots[i].data = (u8*)malloc(DLQ_SLOT_SIZE);
            if (!dlq->slots[i].data) { alloc_ok = false; break; }
        }
        dlq->file = file;
        if (alloc_ok) {
            writer_thread = threadCreate(dlqueue_writer_thread, dlq, 32 * 1024, 0x30, -1, false);
        }
        if (!alloc_ok || !writer_thread) {
            for (int i = 0; i < DLQ_SLOTS; i++) if (dlq->slots[i].data) free(dlq->slots[i].data);
            free(dlq);
            dlq = NULL;
        } else {
            info.dlqueue = dlq;
        }
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
#define DL_MAX_CONSECUTIVE_NO_PROGRESS 6
    unsigned long offset = 0;
    CURLcode res = CURLE_OK;
    int consecutive_no_progress = 0;

    CURL *curl = curl_easy_init();
    if (!curl) { fclose(file); download_in_progress = false; return; }

    curl_easy_setopt(curl, CURLOPT_URL,              url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,    write_file_callback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA,        (void *)&info);
    curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, progress_callback);
    curl_easy_setopt(curl, CURLOPT_XFERINFODATA,     (void*)titles[global_idx].name);
    curl_easy_setopt(curl, CURLOPT_NOPROGRESS,       0L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT,        "3DS-hShop/1.0");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION,   1L);
    
    
    
    
    
    
    
    
    curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS,  CURLPROTO_HTTP);
    curl_easy_setopt(curl, CURLOPT_BUFFERSIZE,       524288L);
    
    
    
    
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER,   0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST,   0L);

    
    
    
    res = curl_easy_perform(curl);
    offset = (unsigned long)info.total_downloaded;
    if (offset > 0) consecutive_no_progress = 0; else consecutive_no_progress = 1;

    while (!download_cancelled &&
           res != CURLE_OK &&
           consecutive_no_progress < DL_MAX_CONSECUTIVE_NO_PROGRESS &&
           !(expected_size > 0 && (long)info.total_downloaded >= expected_size)) {

        
        
        
        
        svcSleepThread((s64)(consecutive_no_progress < 4 ? consecutive_no_progress : 4) * 500000000LL);

        
        
        curl_easy_cleanup(curl);
        curl = curl_easy_init();
        if (!curl) { res = CURLE_FAILED_INIT; break; }

        char range[64];
        snprintf(range, sizeof(range), "%lu-", offset);

        curl_easy_setopt(curl, CURLOPT_URL,              url);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION,    write_file_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA,        (void *)&info);
        curl_easy_setopt(curl, CURLOPT_XFERINFOFUNCTION, progress_callback);
        curl_easy_setopt(curl, CURLOPT_XFERINFODATA,     (void*)titles[global_idx].name);
        curl_easy_setopt(curl, CURLOPT_NOPROGRESS,       0L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT,        "3DS-hShop/1.0");
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION,   1L);
        curl_easy_setopt(curl, CURLOPT_REDIR_PROTOCOLS,  CURLPROTO_HTTP);
        curl_easy_setopt(curl, CURLOPT_BUFFERSIZE,       524288L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER,   0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST,   0L);
        curl_easy_setopt(curl, CURLOPT_RANGE,            range);

        u64 before = info.total_downloaded;
        res = curl_easy_perform(curl);
        u64 received = info.total_downloaded - before;
        offset += received;

        if (received > 0) {
            
            
            
            consecutive_no_progress = 0;
        } else {
            consecutive_no_progress++;
        }

        
        
        
        if (res == CURLE_OK && received == 0) break;
    }
    if (curl) curl_easy_cleanup(curl);

    
    
    
    
    bool disk_full = info.disk_full; 
    if (dlq) {
        dlq->stop = true;
        if (writer_thread) { threadJoin(writer_thread, U64_MAX); threadFree(writer_thread); }
        if (dlq->writer_error && res == CURLE_OK) res = CURLE_WRITE_ERROR;
        if (dlq->disk_full) disk_full = true;
        for (int i = 0; i < DLQ_SLOTS; i++) free(dlq->slots[i].data);
        free(dlq);
    }

    fclose(file);

    if ((res != CURLE_OK && !(expected_size > 0 && (long)info.total_downloaded >= expected_size)) || download_cancelled)
        remove(filepath);
    download_in_progress = false;

    const char* result_msg;
    if (download_cancelled) {
        result_msg = "Download Cancelled";
    } else if (res == CURLE_OK || (expected_size > 0 && (long)info.total_downloaded >= expected_size)) {
        result_msg = "Download Complete!";
    } else if (disk_full) {
        
        
        
        
        
        result_msg = STR(STR_NOT_ENOUGH_SPACE);
    } else {
        
        
        result_msg = STR(STR_DOWNLOAD_FAILED_MSG);
    }
    u32 result_color = C2D_Color32(255, 255, 255, 255);

    while (aptMainLoop()) {
        hidScanInput();
        if (hidKeysDown() & KEY_A) break;

        C2D_TextBufClear(dynamicBuf);
        anim_timer += 0.04f;
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        C2D_TargetClear(top_target, C2D_Color32(255, 255, 255, 255));
        C2D_SceneBegin(top_target);
        if (top_spritesheet) C2D_DrawSprite(&top_sprite);
        if (bags_top_sheet) anim_draw_bags(bags_top_sheet, bags_top, NUM_BAGS_TOP);
        int textIdx = 0;

        float rx = 6.0f, ry = 85.0f, rw = 388.0f, rh = 46.0f;
        draw_rounded_rect(rx,     ry + 3, rw,     rh,     6, 0.27f, C2D_Color32(0, 0, 0, 50));
        draw_rounded_rect(rx - 1, ry - 1, rw + 2, rh + 2, 7, 0.28f, C2D_Color32(220, 0, 0, 120));
        draw_rounded_rect(rx,     ry,     rw,     rh,     6, 0.30f, C2D_Color32(255, 255, 255, 18));
        C2D_TextParse(&text[textIdx], dynamicBuf, result_msg);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 201, ry + 16, 0.5f, 0.70f, 0.70f, result_color);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 200, ry + 15, 0.5f, 0.70f, 0.70f, result_color);
        textIdx++;

        C2D_TextParse(&text[textIdx], dynamicBuf, "A: OK");
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 201, ry + 34, 0.5f, 0.45f, 0.45f, C2D_Color32(255, 255, 255, 160));
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 200, ry + 33, 0.5f, 0.45f, 0.45f, C2D_Color32(255, 255, 255, 160));
        textIdx++;

        C2D_TargetClear(bottom_target, C2D_Color32(255, 255, 255, 255));
        C2D_SceneBegin(bottom_target);
        if (bottom_spritesheet) C2D_DrawSprite(&bottom_sprite);
        if (bags_bot_sheet) anim_draw_bags(bags_bot_sheet, bags_bot, NUM_BAGS_BOT);
        if (!download_cancelled && (res == CURLE_OK || (expected_size > 0 && (long)info.total_downloaded >= expected_size))) {
            draw_rounded_rect(6, 40, 308, 150, 8, 0.30f, C2D_Color32(0, 0, 0, 90));
            C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_DOWNLOAD_SUCCESS_TIP));
            C2D_TextOptimize(&text[textIdx]);
            
            
            
            C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 161, 66, 0.3f, 0.5f, 0.5f, C2D_Color32(255, 255, 255, 230));
            C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 160, 65, 0.3f, 0.5f, 0.5f, C2D_Color32(255, 255, 255, 230));
            textIdx++;
        }
        C3D_FrameEnd(0);
    }

    download_status[0] = '\0';
}

void display_ui(void) {
    int textIdx = 0;

    const float CARD_H   = 52.0f;
    const float CARD_GAP = 4.0f;
    const float CARD_X   = 6.0f;
    const float CARD_W   = 388.0f;
    const int   VISIBLE  = 4;

    int start = scroll_offset;
    int end   = start + VISIBLE;
    if (end > filtered_count) end = filtered_count;

    for (int i = start; i < end && textIdx < 45; i++) {
        int real_i = filtered_indices[i];
        bool sel   = (i == selected_index);
        float cy   = 5.0f + (i - start) * (CARD_H + CARD_GAP);

        if (sel) {
            draw_rounded_rect(CARD_X - 1, cy - 1, CARD_W + 2, CARD_H + 2, 7, 0.28f, C2D_Color32(220, 0, 0, 120));
            draw_rounded_rect(CARD_X,     cy,     CARD_W,     CARD_H,     6, 0.30f, C2D_Color32(255, 255, 255, 210));
        } else {
            draw_rounded_rect(CARD_X,     cy + 3, CARD_W,     CARD_H,     6, 0.27f, C2D_Color32(0, 0, 0, 50));
            draw_rounded_rect(CARD_X,     cy,     CARD_W,     CARD_H,     6, 0.30f, C2D_Color32(255, 255, 255, 28));
        }

        const float ICON_SIZE = 40.0f;
        float icon_x = CARD_X + 5.0f;
        float icon_y = cy + (CARD_H - ICON_SIZE) / 2.0f;
        draw_icon(real_i, icon_x, icon_y, ICON_SIZE, sel);

        u32 name_color = sel ? C2D_Color32(20, 20, 20, 255) : C2D_Color32(255, 255, 255, 255);
        float tx = CARD_X + ICON_SIZE + 12.0f;

        char line1[32], line2[32];
        line2[0] = '\0';
        const char* fullname = titles[real_i].name;
        int nlen = strlen(fullname);

        if (nlen <= 28) {
            strncpy(line1, fullname, 31); line1[31] = '\0';
        } else {
            strncpy(line1, fullname, 28); line1[28] = '\0';

            for (int k = 27; k > 10; k--) {
                if (line1[k] == ' ') { line1[k] = '\0'; break; }
            }
            int l1 = strlen(line1);
            strncpy(line2, fullname + l1 + 1, 30); line2[30] = '\0';
        }

        C2D_TextParse(&text[textIdx], dynamicBuf, line1);
        C2D_TextOptimize(&text[textIdx]);
        float line_y = line2[0] ? cy + 8 : cy + (CARD_H - 13) / 2.0f;
        C2D_DrawText(&text[textIdx], C2D_WithColor, tx + 0.5f, line_y, 0.5f, 0.58f, 0.58f, name_color);
        C2D_DrawText(&text[textIdx], C2D_WithColor, tx,        line_y, 0.5f, 0.58f, 0.58f, name_color);
        textIdx++;

        if (line2[0] && textIdx < 45) {
            C2D_TextParse(&text[textIdx], dynamicBuf, line2);
            C2D_TextOptimize(&text[textIdx]);
            C2D_DrawText(&text[textIdx], C2D_WithColor, tx + 0.5f, cy + 24, 0.5f, 0.58f, 0.58f, name_color);
            C2D_DrawText(&text[textIdx], C2D_WithColor, tx,        cy + 24, 0.5f, 0.58f, 0.58f, name_color);
            textIdx++;
        }
    }

    if (filtered_count == 0 && search_query[0] != '\0') {
        C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_NO_RESULTS));
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, 120.5f, 110, 0.5f, 0.70f, 0.70f, C2D_Color32(195, 195, 195, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor, 120,    110, 0.5f, 0.70f, 0.70f, C2D_Color32(195, 195, 195, 255));
    }
}

static C2D_SpriteSheet loupe_sheet = NULL;

static void loupe_init(void) {
    loupe_sheet = C2D_SpriteSheetLoadFromMem(loupe_t3x, loupe_t3x_size);
}

static void loupe_draw_prim(float x, float y, float w, float h) {
    if (!loupe_sheet) return;
    C2D_Sprite spr;
    C2D_SpriteFromSheet(&spr, loupe_sheet, 0);
    float sw = spr.image.subtex->width;
    float sh = spr.image.subtex->height;
    C2D_DrawImageAt(spr.image, x, y, 0.5f, NULL, w / sw, h / sh);
}

static void gear_draw(float x, float y, float w, float h) {
    if (!gear_spritesheet) return;
    C2D_Sprite spr;
    C2D_SpriteFromSheet(&spr, gear_spritesheet, 0);
    C2D_SpriteSetPos(&spr, x, y);
    C2D_SpriteSetCenter(&spr, 0.0f, 0.0f);
    float sw = spr.image.subtex->width;
    float sh = spr.image.subtex->height;
    C2D_SpriteSetScale(&spr, w / sw, h / sh);
    C2D_DrawSprite(&spr);
}

static void draw_rounded_rect(float x, float y, float w, float h, float r, float z, u32 color) {

    C2D_DrawRectSolid(x,     y + r, z, w,     h - 2*r, color);

    for (int i = 0; i < (int)r; i++) {
        float step = r - i;
        C2D_DrawRectSolid(x + step, y + i,           z, w - 2*step, 1, color);
        C2D_DrawRectSolid(x + step, y + h - 1 - i,  z, w - 2*step, 1, color);
    }
}

#define SETTINGS_ITEMS 5
#define DROPDOWN_VIS   6

void display_settings(void) {
    C2D_TextBufClear(dynamicBuf);
    int tidx = 0;

    draw_rounded_rect(60, 6, 280, 30, 8, 0.45f, C2D_Color32(0, 0, 0, 110));
    C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_SETTINGS_TITLE));
    C2D_TextOptimize(&text[tidx]);
    C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 12, 0.5f, 0.68f, 0.68f, C2D_Color32(255,255,255,255));

    if (!lang_dropdown_open && !filter_dropdown_open && !sort_dropdown_open && !region_dropdown_open && !folder_dropdown_open) {
        draw_rounded_rect(14, 44, 372, 212, 10, 0.46f, C2D_Color32(0, 0, 0, 100));

        {
            bool sel = (settings_sel == 0);
            u32 bg = sel ? C2D_Color32(80,120,200,180) : C2D_Color32(40,40,60,120);
            draw_rounded_rect(24, 52, 352, 30, 6, 0.47f, bg);
            C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_LANGUAGE));
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor, 34, 58, 0.5f, 0.48f, 0.48f, C2D_Color32(200,220,255,255));
            C2D_TextParse(&text[tidx], dynamicBuf, LANG_NAMES[settings_lang]);
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignRight, 370, 58, 0.5f, 0.48f, 0.48f, C2D_Color32(255,220,100,255));
        }

        {
            bool sel = (settings_sel == 1);
            u32 bg = sel ? C2D_Color32(80,120,200,180) : C2D_Color32(40,40,60,120);
            draw_rounded_rect(24, 86, 352, 30, 6, 0.47f, bg);
            C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_FILTER));
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor, 34, 92, 0.5f, 0.48f, 0.48f, C2D_Color32(200,220,255,255));
            const char* filter_val = settings_filter == 0 ? STR(STR_ALL) :
                                      settings_filter == 1 ? STR(STR_NDS_ONLY) : STR(STR_GBA_ONLY);
            C2D_TextParse(&text[tidx], dynamicBuf, filter_val);
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignRight, 370, 92, 0.5f, 0.48f, 0.48f, C2D_Color32(255,220,100,255));
        }

        {
            bool sel = (settings_sel == 2);
            u32 bg = sel ? C2D_Color32(80,120,200,180) : C2D_Color32(40,40,60,120);
            draw_rounded_rect(24, 120, 352, 30, 6, 0.47f, bg);
            C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_SORT_LABEL));
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor, 34, 126, 0.5f, 0.48f, 0.48f, C2D_Color32(200,220,255,255));
            const char* sort_val = settings_sort == 0 ? STR(STR_SORT_OFF) :
                                    settings_sort == 1 ? STR(STR_SORT_ALPHA) : STR(STR_SORT_SIZE);
            C2D_TextParse(&text[tidx], dynamicBuf, sort_val);
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignRight, 370, 126, 0.5f, 0.48f, 0.48f, C2D_Color32(255,220,100,255));
        }

        {
            bool sel = (settings_sel == 3);
            u32 bg = sel ? C2D_Color32(80,120,200,180) : C2D_Color32(40,40,60,120);
            draw_rounded_rect(24, 154, 352, 30, 6, 0.47f, bg);
            C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_REGION_LABEL));
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor, 34, 160, 0.5f, 0.48f, 0.48f, C2D_Color32(200,220,255,255));
            const char* region_val = settings_region == 0 ? STR(STR_ALL) :
                                      settings_region == 1 ? STR(STR_REGION_USA) :
                                      settings_region == 2 ? STR(STR_REGION_EUROPE) : STR(STR_REGION_OTHER);
            C2D_TextParse(&text[tidx], dynamicBuf, region_val);
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignRight, 370, 160, 0.5f, 0.48f, 0.48f, C2D_Color32(255,220,100,255));
        }

        {
            bool sel = (settings_sel == 4);
            u32 bg = sel ? C2D_Color32(80,120,200,180) : C2D_Color32(40,40,60,120);
            draw_rounded_rect(24, 188, 352, 30, 6, 0.47f, bg);
            C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_DOWNLOAD_FOLDER_LABEL));
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor, 34, 194, 0.5f, 0.44f, 0.44f, C2D_Color32(200,220,255,255));
            const char* folder_val = DOWNLOAD_FOLDER_DISPLAY[settings_download_folder_idx];
            C2D_TextParse(&text[tidx], dynamicBuf, folder_val);
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignRight, 370, 194, 0.5f, 0.44f, 0.44f, C2D_Color32(255,220,100,255));
        }

        C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_BACK));
        C2D_TextOptimize(&text[tidx]);
        C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 224, 0.5f, 0.44f, 0.44f, C2D_Color32(160,160,160,180));

    } else if (lang_dropdown_open) {

        C2D_DrawRectSolid(0, 44, 0.44f, 400, 196, C2D_Color32(0,0,0,180));
        draw_rounded_rect(30, 50, 340, DROPDOWN_VIS * 28 + 12, 8, 0.45f, C2D_Color32(20,30,60,230));

        for (int i = 0; i < DROPDOWN_VIS; i++) {
            int li = lang_dropdown_scroll + i;
            if (li >= LANG_COUNT) break;
            bool sel = (li == settings_lang);
            float ry = 56 + i * 28;
            u32 bg = sel ? C2D_Color32(80,140,220,200) : C2D_Color32(30,40,70,0);
            if (sel) draw_rounded_rect(34, ry - 2, 332, 26, 4, 0.46f, bg);
            u32 col = sel ? C2D_Color32(255,255,255,255) : C2D_Color32(200,210,230,220);
            if (tidx < 44) {
                C2D_TextParse(&text[tidx], dynamicBuf, LANG_NAMES[li]);
                C2D_TextOptimize(&text[tidx]);
                C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, ry + 3, 0.46f, 0.55f, 0.55f, col);
            }
        }

        if (LANG_COUNT > DROPDOWN_VIS) {
            float pct = (float)lang_dropdown_scroll / (LANG_COUNT - DROPDOWN_VIS);
            float bar_h = (float)DROPDOWN_VIS / LANG_COUNT * (DROPDOWN_VIS * 28);
            float bar_y = 56 + pct * (DROPDOWN_VIS * 28 - bar_h);
            C2D_DrawRectSolid(366, 56, 0.46f, 3, DROPDOWN_VIS * 28, C2D_Color32(255,255,255,30));
            C2D_DrawRectSolid(366, bar_y, 0.46f, 3, (int)bar_h, C2D_Color32(255,255,255,150));
        }

        C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_OK_CANCEL));
        C2D_TextOptimize(&text[tidx]);
        C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 218, 0.5f, 0.46f, 0.46f, C2D_Color32(160,160,160,180));
    } else if (filter_dropdown_open) {

        C2D_DrawRectSolid(0, 44, 0.44f, 400, 196, C2D_Color32(0,0,0,180));
        draw_rounded_rect(30, 50, 340, 3 * 28 + 12, 8, 0.45f, C2D_Color32(20,30,60,230));

        for (int i = 0; i < 3; i++) {
            bool sel = (i == settings_filter);
            float ry = 56 + i * 28;
            u32 bg = sel ? C2D_Color32(80,140,220,200) : C2D_Color32(30,40,70,0);
            if (sel) draw_rounded_rect(34, ry - 2, 332, 26, 4, 0.46f, bg);
            u32 col = sel ? C2D_Color32(255,255,255,255) : C2D_Color32(200,210,230,220);
            const char* val = i == 0 ? STR(STR_ALL) : i == 1 ? STR(STR_NDS_ONLY) : STR(STR_GBA_ONLY);
            if (tidx < 44) {
                C2D_TextParse(&text[tidx], dynamicBuf, val);
                C2D_TextOptimize(&text[tidx]);
                C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, ry + 3, 0.46f, 0.55f, 0.55f, col);
            }
        }

        C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_OK_CANCEL));
        C2D_TextOptimize(&text[tidx]);
        C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 218, 0.5f, 0.46f, 0.46f, C2D_Color32(160,160,160,180));
    } else if (sort_dropdown_open) {

        C2D_DrawRectSolid(0, 44, 0.44f, 400, 196, C2D_Color32(0,0,0,180));
        draw_rounded_rect(30, 50, 340, 3 * 28 + 12, 8, 0.45f, C2D_Color32(20,30,60,230));

        for (int i = 0; i < 3; i++) {
            bool sel = (i == settings_sort);
            float ry = 56 + i * 28;
            u32 bg = sel ? C2D_Color32(80,140,220,200) : C2D_Color32(30,40,70,0);
            if (sel) draw_rounded_rect(34, ry - 2, 332, 26, 4, 0.46f, bg);
            u32 col = sel ? C2D_Color32(255,255,255,255) : C2D_Color32(200,210,230,220);
            const char* val = i == 0 ? STR(STR_SORT_OFF) : i == 1 ? STR(STR_SORT_ALPHA) : STR(STR_SORT_SIZE);
            if (tidx < 44) {
                C2D_TextParse(&text[tidx], dynamicBuf, val);
                C2D_TextOptimize(&text[tidx]);
                C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, ry + 3, 0.46f, 0.55f, 0.55f, col);
            }
        }

        C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_OK_CANCEL));
        C2D_TextOptimize(&text[tidx]);
        C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 218, 0.5f, 0.46f, 0.46f, C2D_Color32(160,160,160,180));
    } else if (region_dropdown_open) {

        C2D_DrawRectSolid(0, 44, 0.44f, 400, 196, C2D_Color32(0,0,0,180));
        draw_rounded_rect(30, 50, 340, 4 * 28 + 12, 8, 0.45f, C2D_Color32(20,30,60,230));

        for (int i = 0; i < 4; i++) {
            bool sel = (i == settings_region);
            float ry = 56 + i * 28;
            u32 bg = sel ? C2D_Color32(80,140,220,200) : C2D_Color32(30,40,70,0);
            if (sel) draw_rounded_rect(34, ry - 2, 332, 26, 4, 0.46f, bg);
            u32 col = sel ? C2D_Color32(255,255,255,255) : C2D_Color32(200,210,230,220);
            const char* val = i == 0 ? STR(STR_ALL) : i == 1 ? STR(STR_REGION_USA) :
                              i == 2 ? STR(STR_REGION_EUROPE) : STR(STR_REGION_OTHER);
            if (tidx < 44) {
                C2D_TextParse(&text[tidx], dynamicBuf, val);
                C2D_TextOptimize(&text[tidx]);
                C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, ry + 3, 0.46f, 0.55f, 0.55f, col);
            }
        }

        C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_OK_CANCEL));
        C2D_TextOptimize(&text[tidx]);
        C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 218, 0.5f, 0.46f, 0.46f, C2D_Color32(160,160,160,180));
    } else if (folder_dropdown_open) {

        C2D_DrawRectSolid(0, 44, 0.44f, 400, 196, C2D_Color32(0,0,0,180));
        draw_rounded_rect(30, 50, 340, DOWNLOAD_FOLDER_COUNT * 28 + 12, 8, 0.45f, C2D_Color32(20,30,60,230));

        for (int i = 0; i < DOWNLOAD_FOLDER_COUNT; i++) {
            bool sel = (i == settings_download_folder_idx);
            float ry = 56 + i * 28;
            u32 bg = sel ? C2D_Color32(80,140,220,200) : C2D_Color32(30,40,70,0);
            if (sel) draw_rounded_rect(34, ry - 2, 332, 26, 4, 0.46f, bg);
            u32 col = sel ? C2D_Color32(255,255,255,255) : C2D_Color32(200,210,230,220);
            if (tidx < 44) {
                C2D_TextParse(&text[tidx], dynamicBuf, DOWNLOAD_FOLDER_DISPLAY[i]);
                C2D_TextOptimize(&text[tidx]);
                C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, ry + 3, 0.46f, 0.5f, 0.5f, col);
            }
        }

        C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_OK_CANCEL));
        C2D_TextOptimize(&text[tidx]);
        C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 218, 0.5f, 0.46f, 0.46f, C2D_Color32(160,160,160,180));
    }
}

static const char* MANUAL_CONTENT[LANG_COUNT][60] = {

  {"=Manuel utilisateur","",
   "=Installer des jeux NDS",
   "1. T\u00e9l\u00e9charger le fichier .nds",
   "   depuis cette app.",
   "2. Obtenir NDS Forwarder Generator",
   "   via Universal-Updater.",
   "3. G\u00e9n\u00e9rer un forwarder et",
   "   l'installer sur la 3DS.",
   "   Ou utiliser TWiLight Menu++",
   "   pour lancer le .nds directement.","",
   "=Installer des jeux GBA",
   "-Old 3DS / Old 2DS :",
   "  TWiLight Menu++ + GBARunner2.",
   "  Fluide m\u00eame sur vieux mat\u00e9riel.",
   "  \u00c9viter mGBA sur Old 3DS/2DS",
   "  (lag sur Old 3DS/2DS).","",
   "-New 3DS / New 2DS XL :",
   "  mGBA (Universal-Updater)",
   "  meilleures performances.",
   "  TWiLight + GBARunner2 OK aussi.","",
   "=Erreurs courantes",
   "* \u00c9cran noir / pas de connexion :",
   "  V\u00e9rifier Wi-Fi (2.4GHz seul).",
   "  La DS ne supporte pas le 5GHz.","",
   "* T\u00e9l\u00e9chargement interrompu :",
   "  Reprise support\u00e9e. Relancer.","",
   "* Ic\u00f4nes manquantes :",
   "  Normal - charg\u00e9es du serveur.","",
   "* Crash au lancement :",
   "  V\u00e9rifier la carte SD.","",
   "=Cr\u00e9dits",
   "  App & Serveur: Boop",
   "  ctrulib + citro2d",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom",
   "  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=User Manual","",
   "=Installing NDS games",
   "1. Download the .nds file",
   "   from this app.",
   "2. Get NDS Forwarder Generator",
   "   via Universal-Updater.",
   "3. Generate a forwarder and",
   "   install it on your 3DS.",
   "   Or use TWiLight Menu++",
   "   to launch .nds directly.","",
   "=Installing GBA games",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Smooth even on old hardware.",
   "  Avoid mGBA app on Old 3DS/2DS",
   "  (lag on Old 3DS/2DS).","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater)",
   "  gives better performance.",
   "  TWiLight + GBARunner2 OK too.","",
   "=Common errors",
   "* Black screen / no connect:",
   "  Check Wi-Fi (2.4GHz only).",
   "  DS/3DS do not support 5GHz.","",
   "* Download stops midway:",
   "  Resume supported. Restart.","",
   "* Icons not showing:",
   "  Normal - loaded from server.","",
   "* App crashes on launch:",
   "  Check SD card.","",
   "=Credits",
   "  App & Server: Boop",
   "  ctrulib + citro2d",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom",
   "  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=Manuale utente","",
   "=Installare giochi NDS",
   "1. Scaricare il file .nds",
   "   da questa app.",
   "2. Ottenere NDS Forwarder Generator",
   "   tramite Universal-Updater.",
   "3. Generare un forwarder e",
   "   installarlo sulla 3DS.",
   "   O usare TWiLight Menu++",
   "   per avviare il .nds diretto.","",
   "=Installare giochi GBA",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Fluido anche su vecchio hw.",
   "  Evitare l'app mGBA su Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater)",
   "  prestazioni migliori.","",
   "=Errori comuni",
   "* Schermo nero / no connessione:",
   "  Controlla Wi-Fi (solo 2.4GHz).","",
   "* Download interrotto:",
   "  Ripresa supportata.","",
   "* Icone mancanti:",
   "  Normale - caricate dal server.","",
   "=Crediti",
   "  App & Server: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=Benutzerhandbuch","",
   "=NDS-Spiele installieren",
   "1. Die .nds-Datei herunterladen",
   "   von dieser App.",
   "2. NDS Forwarder Generator holen",
   "   via Universal-Updater.",
   "3. Forwarder erstellen und",
   "   auf der 3DS installieren.",
   "   Oder TWiLight Menu++ nutzen",
   "   um .nds direkt zu starten.","",
   "=GBA-Spiele installieren",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  mGBA-App auf Old 3DS/2DS vermeiden.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater)",
   "  bessere Leistung.","",
   "=H\u00e4ufige Fehler",
   "* Schwarzer Bildschirm:",
   "  WLAN pr\u00fcfen (nur 2.4GHz).","",
   "* Download unterbrochen:",
   "  Fortsetzung unterst\u00fctzt.","",
   "=Credits",
   "  App & Server: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=Gebruikershandleiding","",
   "=NDS-spellen installeren",
   "1. Download het .nds-bestand",
   "   vanuit deze app.",
   "2. NDS Forwarder Generator halen",
   "   via Universal-Updater.",
   "3. Forwarder genereren en",
   "   installeren op de 3DS.","",
   "=GBA-spellen installeren",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Vermijd de mGBA-app op Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater).","",
   "=Veelvoorkomende fouten",
   "* Zwart scherm:",
   "  Wi-Fi controleren (2.4GHz).","",
   "* Download onderbroken:",
   "  Hervatten ondersteund.","",
   "=Credits",
   "  App & Server: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=Manual de usuario","",
   "=Instalar juegos NDS",
   "1. Descargar el archivo .nds",
   "   desde esta app.",
   "2. Obtener NDS Forwarder Generator",
   "   via Universal-Updater.",
   "3. Generar un forwarder e",
   "   instalarlo en la 3DS.","",
   "=Instalar juegos GBA",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Evita la app mGBA en Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater).","",
   "=Errores comunes",
   "* Pantalla negra:",
   "  Comprobar Wi-Fi (2.4GHz).","",
   "* Descarga interrumpida:",
   "  Reanudaci\u00f3n soportada.","",
   "=Cr\u00e9ditos",
   "  App & Servidor: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=Manual do utilizador","",
   "=Instalar jogos NDS",
   "1. Descarregar o ficheiro .nds",
   "   desta app.",
   "2. Obter NDS Forwarder Generator",
   "   via Universal-Updater.",
   "3. Gerar um forwarder e",
   "   instalar na 3DS.","",
   "=Instalar jogos GBA",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Evite a app mGBA na Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater).","",
   "=Erros comuns",
   "* Ecr\u00e3 preto:",
   "  Verificar Wi-Fi (2.4GHz).","",
   "* Transfer\u00eancia interrompida:",
   "  Retoma suportada.","",
   "=Cr\u00e9ditos",
   "  App & Servidor: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=Podr\u0119cznik u\u017cytkownika","",
   "=Instalowanie gier NDS",
   "1. Pobierz plik .nds",
   "   z tej aplikacji.",
   "2. Pobierz NDS Forwarder Generator",
   "   przez Universal-Updater.",
   "3. Wygeneruj forwarder i",
   "   zainstaluj na 3DS.","",
   "=Instalowanie gier GBA",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Unikaj aplikacji mGBA na Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater).","",
   "=Cz\u0119ste b\u0142\u0119dy",
   "* Czarny ekran:",
   "  Sprawd\u017a Wi-Fi (2.4GHz).","",
   "* Pobieranie przerwane:",
   "  Wznawianie obs\u0142ugiwane.","",
   "=Autorzy",
   "  App & Serwer: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=\u0420\u0443\u043a\u043e\u0432\u043e\u0434\u0441\u0442\u0432\u043e","",
   "=\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u0438\u0433\u0440 NDS",
   "1. \u0421\u043a\u0430\u0447\u0430\u0442\u044c .nds \u0444\u0430\u0439\u043b",
   "   \u0438\u0437 \u044d\u0442\u043e\u0433\u043e \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u044f.",
   "2. \u041f\u043e\u043b\u0443\u0447\u0438\u0442\u044c NDS Forwarder Generator",
   "   \u0447\u0435\u0440\u0435\u0437 Universal-Updater.",
   "3. \u0421\u0433\u0435\u043d\u0435\u0440\u0438\u0440\u043e\u0432\u0430\u0442\u044c forwarder \u0438",
   "   \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u0438\u0442\u044c \u043d\u0430 3DS.","",
   "=\u0423\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0430 \u0438\u0433\u0440 GBA",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  \u0418\u0437\u0431\u0435\u0433\u0430\u0439\u0442\u0435 \u043f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435 mGBA \u043d\u0430 Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater).","",
   "=\u0427\u0430\u0441\u0442\u044b\u0435 \u043e\u0448\u0438\u0431\u043a\u0438",
   "* \u0427\u0451\u0440\u043d\u044b\u0439 \u044d\u043a\u0440\u0430\u043d:",
   "  \u041f\u0440\u043e\u0432\u0435\u0440\u0438\u0442\u044c Wi-Fi (2.4\u0413\u0413\u0446).","",
   "* \u0417\u0430\u0433\u0440\u0443\u0437\u043a\u0430 \u043f\u0440\u0435\u0440\u0432\u0430\u043d\u0430:",
   "  \u0412\u043e\u0437\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d\u0438\u0435 \u043f\u043e\u0434\u0434\u0435\u0440\u0436\u0438\u0432\u0430\u0435\u0442\u0441\u044f.","",
   "=\u0410\u0432\u0442\u043e\u0440\u044b",
   "  \u041f\u0440\u0438\u043b\u043e\u0436\u0435\u043d\u0438\u0435: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},

  {"=\u041f\u0440\u0438\u0440\u0443\u0447\u043d\u0438\u043a","",
   "=\u0418\u043d\u0441\u0442\u0430\u043b\u0430\u0446\u0438j\u0430 NDS \u0438\u0433\u0430\u0440\u0430",
   "1. \u041f\u0440\u0435\u0443\u0437\u043c\u0438 .nds \u0444\u0430j\u043b",
   "   \u0438\u0437 \u043e\u0432\u0435 \u0430\u043f\u043b\u0438\u043a\u0430\u0446\u0438j\u0435.",
   "2. \u041d\u0430\u0431\u0430\u0432\u0438 NDS Forwarder Generator",
   "   \u043f\u0440\u0435\u043a\u043e Universal-Updater.",
   "3. \u0413\u0435\u043d\u0435\u0440\u0438\u0448\u0438 forwarder \u0438",
   "   \u0438\u043d\u0441\u0442\u0430\u043b\u0438\u0440\u0430j \u043d\u0430 3DS.","",
   "=\u0418\u043d\u0441\u0442\u0430\u043b\u0430\u0446\u0438j\u0430 GBA \u0438\u0433\u0430\u0440\u0430",
   "-Old 3DS / Old 2DS:",
   "  TWiLight Menu++ + GBARunner2.",
   "  Izbegavaj mGBA aplikaciju na Old 3DS/2DS.","",
   "-New 3DS / New 2DS XL:",
   "  mGBA (Universal-Updater).","",
   "=\u0427\u0435\u0441\u0442\u0435 \u0433\u0440\u0435\u0448\u043a\u0435",
   "* \u0426\u0440\u043d\u0438 \u0435\u043a\u0440\u0430\u043d:",
   "  \u041f\u0440\u043e\u0432\u0435\u0440\u0438 Wi-Fi (2.4GHz).","",
   "* \u041f\u0440\u0435\u0443\u0437\u0438\u043c\u0430nj\u0435 \u043f\u0440\u0435\u043a\u0438\u043d\u0443\u0442\u043e:",
   "  \u041d\u0430\u0441\u0442\u0430\u0432\u0430\u043a \u043f\u043e\u0434\u0440\u0436\u0430\u043d.","",
   "=\u041a\u0440\u0435\u0434\u0438\u0442\u0438",
   "  \u0410\u043f\u043b\u0438\u043a\u0430\u0446\u0438j\u0430: Boop",
   "  NDS Forwarder: MechanicalDragon0687",
   "  TWiLight Menu++: RocketRobz",
   "  GBARunner2: Gericom  mGBA: endrift",
   "",NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL},
};

void display_manual(void) {
    C2D_TextBufClear(dynamicBuf);
    int tidx = 0;

    draw_rounded_rect(60, 5, 280, 30, 8, 0.45f, C2D_Color32(0, 0, 0, 100));
    C2D_TextParse(&text[tidx], dynamicBuf, STR(STR_MANUAL_TITLE));
    C2D_TextOptimize(&text[tidx]);
    C2D_DrawText(&text[tidx++], C2D_WithColor | C2D_AlignCenter, 200, 11, 0.5f, 0.68f, 0.68f, C2D_Color32(255,255,255,255));

    draw_rounded_rect(14, 44, 372, 188, 10, 0.46f, C2D_Color32(0, 0, 0, 100));
    const float LINE_H = 15.0f;
    const float START_Y = 50.0f;
    const float PAD_X   = 24.0f;
    const int   VIS = 12;
    for (int i = 0; i < VIS; i++) {
        int li = manual_scroll + i;
        if (MANUAL_CONTENT[settings_lang][li] == NULL) break;
        const char* line = MANUAL_CONTENT[settings_lang][li];
        const char* display_line = line;
        float y = START_Y + i * LINE_H;
        u32 col;
        float scl;
        if (line[0] == '=')      { col = C2D_Color32(255, 220, 80,  255); scl = 0.52f; display_line = line + 1; }
        else if (line[0] == '-') { col = C2D_Color32(120, 200, 255, 255); scl = 0.50f; display_line = line + 1; }
        else if (line[0] == '*') { col = C2D_Color32(255, 160, 120, 255); scl = 0.48f; }
        else                     { col = C2D_Color32(230, 230, 230, 255); scl = 0.47f; }
        if (tidx < 44) {
            C2D_TextParse(&text[tidx], dynamicBuf, display_line);
            C2D_TextOptimize(&text[tidx]);
            C2D_DrawText(&text[tidx++], C2D_WithColor, PAD_X, y, 0.5f, scl, scl, col);
        }
    }

    int total = 0; while (MANUAL_CONTENT[settings_lang][total]) total++;
    if (total > VIS) {
        float pct   = (float)manual_scroll / (total - VIS);
        float bar_y = 48 + pct * 170;
        C2D_DrawRectSolid(381, 48, 0.5f, 4, 184, C2D_Color32(255,255,255,30));
        C2D_DrawRectSolid(381, bar_y, 0.5f, 4, 24, C2D_Color32(255,255,255,160));
    }
}

void display_main_menu(void) {
    int textIdx = 25;
    const char* items[] = { STR(STR_GAMES), STR(STR_SETTINGS_MENU), STR(STR_MANUAL_MENU) };
    int n = 3;

    C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_MAIN_MENU));
    C2D_TextOptimize(&text[textIdx]);
    C2D_DrawText(&text[textIdx], C2D_WithColor, 106.5f, 15, 0.5f, 0.90f, 0.90f, C2D_Color32(255,255,255,255));
    C2D_DrawText(&text[textIdx], C2D_WithColor, 106,    15, 0.5f, 0.90f, 0.90f, C2D_Color32(255,255,255,255));
    textIdx++;

    float btn_w = 210.0f;
    float btn_h = 32.0f;
    float btn_x = (320.0f - btn_w) / 2.0f;
    float start_y = 50.0f;
    float gap = 42.0f;
    float r = 14.0f;

    for (int i = 0; i < n; i++) {
        float by = start_y + i * gap;
        bool sel = (i == menu_selected);

        if (sel) {

            draw_rounded_rect(btn_x,  by + 3, btn_w,     btn_h,     r,     0.27f, C2D_Color32(140,140,140, 80));
            draw_rounded_rect(btn_x,  by,     btn_w,     btn_h,     r,     0.30f, C2D_Color32(255,255,255, 220));
        } else {

            draw_rounded_rect(btn_x - 1, by - 1, btn_w + 2, btn_h + 2, r + 1, 0.28f, C2D_Color32(100,160,255, 120));
            draw_rounded_rect(btn_x,     by,     btn_w,     btn_h,     r,     0.30f, C2D_Color32(30, 80, 180, 140));
        }

        u32 tc = sel ? C2D_Color32(20,20,20,255) : C2D_Color32(255,255,255,255);

        float scale = 0.75f;
        float tw = strlen(items[i]) * 9.0f * scale;
        float tx = btn_x + (btn_w - tw) / 2.0f;
        float ty = by + (btn_h - 14.0f) / 2.0f;

        C2D_TextParse(&text[textIdx], dynamicBuf, items[i]);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, tx + 0.5f, ty, 0.5f, scale, scale, tc);
        C2D_DrawText(&text[textIdx], C2D_WithColor, tx,        ty, 0.5f, scale, scale, tc);
        textIdx++;
    }
}

void display_ui_bottom(void) {
    int textIdx = 25;
    char tempStr[256];

    u32 bar_bg     = (search_query[0] != '\0') ? C2D_Color32(220, 0, 0, 8)   : C2D_Color32(255, 255, 255, 2);
    u32 bar_border = (search_query[0] != '\0') ? C2D_Color32(220, 0, 0, 70)  : C2D_Color32(255, 255, 255, 20);

    draw_rounded_rect(SEARCHBAR_X - 1, SEARCHBAR_Y - 1, SEARCHBAR_W + 2, SEARCHBAR_H + 2, SEARCHBAR_R + 1, 0.3f, bar_border);

    draw_rounded_rect(SEARCHBAR_X, SEARCHBAR_Y, SEARCHBAR_W, SEARCHBAR_H, SEARCHBAR_R, 0.4f, bar_bg);

    float line_y = SEARCHBAR_Y + SEARCHBAR_H + 6.0f;
    C2D_DrawRectSolid(0, line_y, 0.5f, 320, 1, C2D_Color32(255, 255, 255, 60));

    float loupe_size = SEARCHBAR_H - 4.0f;
    loupe_draw_prim(SEARCHBAR_X + 3.0f, SEARCHBAR_Y + 2.0f, loupe_size, loupe_size);

    float text_x = SEARCHBAR_X + 22.0f;

    char bar_text[64];
    if (search_query[0] != '\0')
        snprintf(bar_text, sizeof(bar_text), "Search: %.22s", search_query);
    else
        snprintf(bar_text, sizeof(bar_text), "Search:");

    u32 text_color = C2D_Color32(255, 255, 255, 255);
    C2D_TextParse(&text[textIdx], dynamicBuf, bar_text);
    C2D_TextOptimize(&text[textIdx]);
    C2D_DrawText(&text[textIdx], C2D_WithColor, text_x, SEARCHBAR_Y + (SEARCHBAR_H - 12) / 2.0f - 2.0f, 0.5f, 0.55f, 0.55f, text_color);
    textIdx++;

    if (search_query[0] != '\0') {
        char count_str[32];
        snprintf(count_str, sizeof(count_str), "%d result(s)", filtered_count);
        C2D_TextParse(&text[textIdx], dynamicBuf, count_str);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, SEARCHBAR_X + 25.5f, SEARCHBAR_Y + 28, 0.5f, 0.52f, 0.52f, C2D_Color32(195, 195, 195, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor, SEARCHBAR_X + 25.0f, SEARCHBAR_Y + 28, 0.5f, 0.52f, 0.52f, C2D_Color32(195, 195, 195, 255));
        textIdx++;
    }

    gear_draw(GEAR_X, GEAR_Y, (float)GEAR_W, (float)GEAR_H);

    #define CARD_BOT_X   10.0f
    #define CARD_BOT_Y   36.0f
    #define CARD_BOT_W  300.0f
    #define CARD_BOT_H  150.0f
    #define CARD_BOT_R    8.0f

    if (filtered_count == 0) {

        draw_rounded_rect(CARD_BOT_X + 1, CARD_BOT_Y + 2, CARD_BOT_W, CARD_BOT_H, CARD_BOT_R, 0.38f, C2D_Color32(0, 0, 0, 18));
        draw_rounded_rect(CARD_BOT_X,     CARD_BOT_Y,     CARD_BOT_W, CARD_BOT_H, CARD_BOT_R, 0.40f, C2D_Color32(255, 255, 255, 18));
        C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_NO_GAME));
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 161, 111, 0.5f, 0.60f, 0.60f, C2D_Color32(180, 180, 180, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 160, 110, 0.5f, 0.60f, 0.60f, C2D_Color32(180, 180, 180, 255));
        textIdx++;
    } else {
        int real_idx = filtered_indices[selected_index];

        draw_rounded_rect(CARD_BOT_X + 2, CARD_BOT_Y + 3, CARD_BOT_W, CARD_BOT_H, CARD_BOT_R, 0.38f, C2D_Color32(0, 0, 0, 18));

        draw_rounded_rect(CARD_BOT_X, CARD_BOT_Y, CARD_BOT_W, CARD_BOT_H, CARD_BOT_R, 0.40f, C2D_Color32(255, 255, 255, 18));

        #define HDR_H 26.0f
        draw_rounded_rect(CARD_BOT_X,     CARD_BOT_Y,           CARD_BOT_W, HDR_H + CARD_BOT_R, CARD_BOT_R, 0.42f, C2D_Color32(210, 30, 30, 120));
        draw_rounded_rect(CARD_BOT_X,     CARD_BOT_Y + HDR_H,   CARD_BOT_W, CARD_BOT_R,         0,          0.42f, C2D_Color32(210, 30, 30, 120));

        C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_GAME_DETAILS));
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 161, CARD_BOT_Y + 7, 0.42f, 0.72f, 0.72f, C2D_Color32(255, 255, 255, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor | C2D_AlignCenter, 160, CARD_BOT_Y + 6, 0.42f, 0.72f, 0.72f, C2D_Color32(255, 255, 255, 255));
        textIdx++;

        float content_y = CARD_BOT_Y + HDR_H + 10.0f;
        const char* full_name = titles[real_idx].name;
        int name_len = strlen(full_name);
        const int CPL = 32;
        int pos = 0, line = 0;
        while (pos < name_len && line < 2 && textIdx < 48) {
            char ln[40];
            int le = pos + CPL;
            if (line < 1 && le < name_len) {
                for (int i = le; i > pos; i--) { if (full_name[i] == ' ') { le = i; break; } }
            } else { le = name_len; }
            int cl = le - pos; if (cl > 39) cl = 39;
            strncpy(ln, full_name + pos, cl); ln[cl] = '\0';
            C2D_TextParse(&text[textIdx], dynamicBuf, ln);
            C2D_TextOptimize(&text[textIdx]);
            C2D_DrawText(&text[textIdx], C2D_WithColor, CARD_BOT_X + 13.5f, content_y + 0.5f, 0.45f, 0.62f, 0.62f, C2D_Color32(255, 255, 255, 255));
            C2D_DrawText(&text[textIdx], C2D_WithColor, CARD_BOT_X + 13.0f, content_y,        0.45f, 0.62f, 0.62f, C2D_Color32(255, 255, 255, 255));
            textIdx++;
            pos = le; if (pos < name_len && full_name[pos] == ' ') pos++;
            content_y += 16.0f; line++;
        }

        content_y += 4.0f;
        C2D_DrawRectSolid(CARD_BOT_X + 10, content_y, 0.45f, CARD_BOT_W - 20, 1, C2D_Color32(255, 255, 255, 60));
        content_y += 8.0f;

        snprintf(tempStr, 256, "Platform:  %s", titles[real_idx].platform);
        C2D_TextParse(&text[textIdx], dynamicBuf, tempStr);
        C2D_TextOptimize(&text[textIdx]);

        C2D_DrawText(&text[textIdx], C2D_WithColor, CARD_BOT_X + 13.5f, content_y + 0.5f, 0.45f, 0.60f, 0.60f, C2D_Color32(240, 240, 240, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor, CARD_BOT_X + 13.0f, content_y,        0.45f, 0.60f, 0.60f, C2D_Color32(240, 240, 240, 255));
        textIdx++;
        content_y += 18.0f;

        snprintf(tempStr, 256, "Size:          %s", titles[real_idx].size);
        C2D_TextParse(&text[textIdx], dynamicBuf, tempStr);
        C2D_TextOptimize(&text[textIdx]);
        C2D_DrawText(&text[textIdx], C2D_WithColor, CARD_BOT_X + 13.5f, content_y + 0.5f, 0.45f, 0.60f, 0.60f, C2D_Color32(240, 240, 240, 255));
        C2D_DrawText(&text[textIdx], C2D_WithColor, CARD_BOT_X + 13.0f, content_y,        0.45f, 0.60f, 0.60f, C2D_Color32(240, 240, 240, 255));
        textIdx++;
    }

}

void sanitize_filename(const char* input, char* output, int max_len) {
    int j = 0;
    for (int i = 0; input[i] != '\0' && j < max_len - 1; i++) {
        char c = input[i];
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
            (c >= '0' && c <= '9') || c == '-' || c == '_' || c == ' ')
            output[j++] = c;
    }
    output[j] = '\0';
}

typedef struct { volatile bool done; char* result; } FetchCtx;
static FetchCtx fetch_ctx;
static void fetch_thread_fn(void* arg) {
    FetchCtx* c = (FetchCtx*)arg;
    c->result = http_get_json();
    c->done   = true;
}

int main(int argc, char **argv) {
    romfsInit();
    gfxInitDefault();

    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    top_target    = C2D_CreateScreenTarget(GFX_TOP,    GFX_LEFT);
    bottom_target = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);

    dynamicBuf = C2D_TextBufNew(4096);

    C2D_TextBufClear(dynamicBuf);
    C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
    C2D_TargetClear(top_target,    C2D_Color32(255, 255, 255, 255));
    C2D_SceneBegin(top_target);
    int textIdx = 0;
    C2D_TextParse(&text[textIdx], dynamicBuf, STR(STR_LOADING));
    C2D_TextOptimize(&text[textIdx]);
    C2D_DrawText(&text[textIdx], C2D_WithColor, 150, 110, 0.5f, 0.6f, 0.6f, C2D_Color32(255, 255, 255, 255));
    C2D_TargetClear(bottom_target, C2D_Color32(255, 255, 255, 255));
    C2D_SceneBegin(bottom_target);
    C3D_FrameEnd(0);

    top_spritesheet    = C2D_SpriteSheetLoadFromMem(top_bg_t3x,    top_bg_t3x_size);
    bottom_spritesheet = C2D_SpriteSheetLoadFromMem(bottom_bg_t3x, bottom_bg_t3x_size);

    if (!top_spritesheet)    printf("ERREUR: top_spritesheet non charge!\n");
    if (!bottom_spritesheet) printf("ERREUR: bottom_spritesheet non charge!\n");

    if (top_spritesheet) {
        C2D_SpriteFromSheet(&top_sprite, top_spritesheet, 0);
        C2D_SpriteSetPos(&top_sprite, 0, 0);
    }
    if (bottom_spritesheet) {
        C2D_SpriteFromSheet(&bottom_sprite, bottom_spritesheet, 0);
        C2D_SpriteSetPos(&bottom_sprite, 0, 0);
    }

    bags_top_sheet = C2D_SpriteSheetLoadFromMem(sprites_top_t3x, sprites_top_t3x_size);
    bags_bot_sheet = C2D_SpriteSheetLoadFromMem(sprites_bot_t3x, sprites_bot_t3x_size);

    gear_spritesheet = C2D_SpriteSheetLoadFromMem(gear_t3x, gear_t3x_size);
    loupe_init();

    anim_init_bags_top();
    anim_init_bags_bot();

    SOC_buffer = (u32*)memalign(SOC_ALIGN, SOC_BUFFERSIZE);
    if (SOC_buffer == NULL) goto cleanup;

    Result ret = socInit(SOC_buffer, SOC_BUFFERSIZE);
    if (R_FAILED(ret)) goto cleanup;

    ndspInit();
    ndspSetOutputMode(NDSP_OUTPUT_STEREO);
    ndspChnReset(0);
    ndspChnWaveBufClear(0);
    ndspChnSetInterp(0, NDSP_INTERP_LINEAR);
    ndspChnSetRate(0, 48000.0f);
    ndspChnSetFormat(0, NDSP_FORMAT_STEREO_PCM16);

    if (load_wav_file("romfs:/audio/bgm.wav")) {
        ndspChnWaveBufAdd(0, &waveBuf);
        audio_loaded = true;
    }

    if (access("sdmc:/", F_OK) != 0) goto cleanup;

    char* json_data = NULL;
    {
        fetch_ctx.done = false; fetch_ctx.result = NULL;
        Thread fetch_th = threadCreate(fetch_thread_fn, &fetch_ctx, 32*1024, 0x30, -1, false);

        const float scx = 200.0f, scy = 120.0f;
        const float orbit = 26.0f, dot_r = 6.0f;
        const int   NDOTS = 8;
        const u8    alphas[8] = {255, 210, 170, 130, 90, 60, 35, 15};
        int spin = 0;

        while (!fetch_ctx.done && aptMainLoop()) {
            C3D_FrameBegin(C3D_FRAME_SYNCDRAW);
            C2D_TargetClear(top_target, C2D_Color32(18, 18, 38, 255));
            C2D_SceneBegin(top_target);
            if (top_spritesheet) C2D_DrawSprite(&top_sprite);
            for (int d = 0; d < NDOTS; d++) {
                float angle = (float)d * (2.0f * M_PI / NDOTS) - (M_PI / 2.0f);
                float px2 = scx + cosf(angle) * orbit;
                float py2 = scy + sinf(angle) * orbit;
                int   rel = ((d - spin) % NDOTS + NDOTS) % NDOTS;
                u32   col = C2D_Color32(255, 255, 255, alphas[rel]);
                C2D_DrawCircle(px2, py2, 0.5f, dot_r, col, col, col, col);
            }
            C2D_TargetClear(bottom_target, C2D_Color32(18, 18, 38, 255));
            C2D_SceneBegin(bottom_target);
            if (bottom_spritesheet) C2D_DrawSprite(&bottom_sprite);
            C3D_FrameEnd(0);
            spin = (spin + 1) % NDOTS;
            svcSleepThread(80000000LL);
        }
        threadJoin(fetch_th, U64_MAX);
        threadFree(fetch_th);
        json_data = fetch_ctx.result;
    }
    if (!json_data) goto cleanup;

    parse_json_titles(json_data);
    free(json_data);

    if (title_count == 0) goto cleanup;

    update_filtered_list();

    icon_system_init();
    icon_system_start();

    int repeat_delay = 0;
    const int REPEAT_INITIAL_DELAY = 30;
    const int REPEAT_SPEED         = 12;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();
        touchPosition touch;
        hidTouchRead(&touch);

        if (kDown & KEY_START) break;
        if (kDown & KEY_B && (app_state == STATE_GAMES || app_state == STATE_SETTINGS || app_state == STATE_MANUAL)) {
            if (app_state == STATE_SETTINGS && (lang_dropdown_open || filter_dropdown_open || sort_dropdown_open || region_dropdown_open || folder_dropdown_open)) {
                lang_dropdown_open = false;
                filter_dropdown_open = false;
                sort_dropdown_open = false;
                region_dropdown_open = false;
                folder_dropdown_open = false;
            } else {
                app_state = STATE_MENU;
            }
        }

        if (!download_in_progress) {

            if (app_state == STATE_MENU) {
                if (kDown & KEY_DOWN) menu_selected = (menu_selected + 1) % 3;
                if (kDown & KEY_UP)   menu_selected = (menu_selected + 2) % 3;
                if (kDown & KEY_A) {
                    if      (menu_selected == 0) app_state = STATE_GAMES;
                    else if (menu_selected == 1) app_state = STATE_SETTINGS;
                    else if (menu_selected == 2) app_state = STATE_MANUAL;
                }
                if (kDown & KEY_TOUCH) {
                    float btn_x = (320.0f - 210.0f) / 2.0f;
                    float start_y = 50.0f;
                    for (int i = 0; i < 3; i++) {
                        float by = start_y + i * 42.0f;
                        if (touch.px >= btn_x && touch.px <= btn_x + 210 &&
                            touch.py >= by    && touch.py <= by + 32) {
                            menu_selected = i;
                            if      (i == 0) app_state = STATE_GAMES;
                            else if (i == 1) app_state = STATE_SETTINGS;
                            else if (i == 2) app_state = STATE_MANUAL;
                        }
                    }
                }
            } else if (app_state == STATE_SETTINGS) {
                if (lang_dropdown_open) {

                    if (kDown & KEY_DOWN) {
                        int cur = settings_lang;
                        int next = (cur + 1) % LANG_COUNT;
                        settings_lang = next;

                        if (settings_lang >= lang_dropdown_scroll + DROPDOWN_VIS)
                            lang_dropdown_scroll = settings_lang - DROPDOWN_VIS + 1;
                        if (settings_lang < lang_dropdown_scroll)
                            lang_dropdown_scroll = settings_lang;
                    }
                    if (kDown & KEY_UP) {
                        settings_lang = (settings_lang - 1 + LANG_COUNT) % LANG_COUNT;
                        if (settings_lang < lang_dropdown_scroll)
                            lang_dropdown_scroll = settings_lang;
                        if (settings_lang >= lang_dropdown_scroll + DROPDOWN_VIS)
                            lang_dropdown_scroll = settings_lang - DROPDOWN_VIS + 1;
                    }
                    if (kDown & KEY_A) lang_dropdown_open = false;
                    if (kDown & KEY_B) {
                        lang_dropdown_open = false;
                    }
                } else if (filter_dropdown_open) {

                    if (kDown & KEY_DOWN) settings_filter = (settings_filter + 1) % 3;
                    if (kDown & KEY_UP)   settings_filter = (settings_filter + 2) % 3;
                    if (kDown & KEY_A) {
                        filter_dropdown_open = false;
                        selected_index = 0; scroll_offset = 0;
                        search_query[0] = '\0';
                        update_filtered_list();
                    }
                    if (kDown & KEY_B) {
                        filter_dropdown_open = false;
                    }
                } else if (sort_dropdown_open) {

                    if (kDown & KEY_DOWN) settings_sort = (settings_sort + 1) % 3;
                    if (kDown & KEY_UP)   settings_sort = (settings_sort + 2) % 3;
                    if (kDown & KEY_A) {
                        sort_dropdown_open = false;
                        selected_index = 0; scroll_offset = 0;
                        update_filtered_list();
                    }
                    if (kDown & KEY_B) {
                        sort_dropdown_open = false;
                    }
                } else if (region_dropdown_open) {

                    if (kDown & KEY_DOWN) settings_region = (settings_region + 1) % 4;
                    if (kDown & KEY_UP)   settings_region = (settings_region + 3) % 4;
                    if (kDown & KEY_A) {
                        region_dropdown_open = false;
                        selected_index = 0; scroll_offset = 0;
                        update_filtered_list();
                    }
                    if (kDown & KEY_B) {
                        region_dropdown_open = false;
                    }
                } else if (folder_dropdown_open) {

                    if (kDown & KEY_DOWN) settings_download_folder_idx = (settings_download_folder_idx + 1) % DOWNLOAD_FOLDER_COUNT;
                    if (kDown & KEY_UP)   settings_download_folder_idx = (settings_download_folder_idx + DOWNLOAD_FOLDER_COUNT - 1) % DOWNLOAD_FOLDER_COUNT;
                    if (kDown & KEY_A) {
                        folder_dropdown_open = false;
                        apply_download_folder(settings_download_folder_idx);
                    }
                    if (kDown & KEY_B) {
                        folder_dropdown_open = false;
                    }
                } else {

                    if (kDown & KEY_DOWN) settings_sel = (settings_sel + 1) % SETTINGS_ITEMS;
                    if (kDown & KEY_UP)   settings_sel = (settings_sel - 1 + SETTINGS_ITEMS) % SETTINGS_ITEMS;
                    if (kDown & KEY_A) {
                        if (settings_sel == 0) {
                            lang_dropdown_open = true;
                            lang_dropdown_scroll = settings_lang > DROPDOWN_VIS/2 ?
                                settings_lang - DROPDOWN_VIS/2 : 0;
                            if (lang_dropdown_scroll > LANG_COUNT - DROPDOWN_VIS)
                                lang_dropdown_scroll = LANG_COUNT - DROPDOWN_VIS;
                        } else if (settings_sel == 1) {
                            filter_dropdown_open = true;
                        } else if (settings_sel == 2) {
                            sort_dropdown_open = true;
                        } else if (settings_sel == 3) {
                            region_dropdown_open = true;
                        } else if (settings_sel == 4) {
                            folder_dropdown_open = true;
                        }
                    }
                }
            } else if (app_state == STATE_MANUAL) {

                int manual_total = 0;
                while (manual_total < 60 && MANUAL_CONTENT[settings_lang][manual_total] != NULL)
                    manual_total++;
                const int MANUAL_VIS = 12;

                
                
                
                static int manual_repeat_timer = 0;
                const int REPEAT_DELAY = 20; 
                const int REPEAT_RATE  = 4;  

                if (kDown & KEY_DOWN) {
                    if (manual_scroll < manual_total - MANUAL_VIS) manual_scroll++;
                    manual_repeat_timer = 0;
                } else if (kDown & KEY_UP) {
                    if (manual_scroll > 0) manual_scroll--;
                    manual_repeat_timer = 0;
                } else if (kHeld & KEY_DOWN) {
                    manual_repeat_timer++;
                    if (manual_repeat_timer > REPEAT_DELAY &&
                        (manual_repeat_timer - REPEAT_DELAY) % REPEAT_RATE == 0 &&
                        manual_scroll < manual_total - MANUAL_VIS) {
                        manual_scroll++;
                    }
                } else if (kHeld & KEY_UP) {
                    manual_repeat_timer++;
                    if (manual_repeat_timer > REPEAT_DELAY &&
                        (manual_repeat_timer - REPEAT_DELAY) % REPEAT_RATE == 0 &&
                        manual_scroll > 0) {
                        manual_scroll--;
                    }
                } else {
                    manual_repeat_timer = 0;
                }
            } else {

            if (kDown & KEY_TOUCH) {
                if (touch.px >= MAGNIFIER_X && touch.px <= MAGNIFIER_X + MAGNIFIER_W &&
                    touch.py >= MAGNIFIER_Y && touch.py <= MAGNIFIER_Y + MAGNIFIER_H) {
                    open_search_keyboard();
                }
            }

            if (kDown & KEY_TOUCH) {
                if (touch.px >= GEAR_TOUCH_X && touch.px <= GEAR_TOUCH_X + GEAR_TOUCH_W &&
                    touch.py >= GEAR_TOUCH_Y && touch.py <= GEAR_TOUCH_Y + GEAR_TOUCH_H) {
                    app_state = STATE_SETTINGS;
                }
            }

            bool should_move_down = false;
            if (kDown & KEY_DOWN) {
                should_move_down = true;
                repeat_delay = REPEAT_INITIAL_DELAY;
            } else if (kHeld & KEY_DOWN) {
                repeat_delay--;
                if (repeat_delay <= 0) { should_move_down = true; repeat_delay = REPEAT_SPEED; }
            }
            if (should_move_down && filtered_count > 0) {
                if (selected_index < filtered_count - 1) {
                    selected_index++;
                    if (selected_index >= scroll_offset + 4 - 1)
                        scroll_offset = selected_index - (4 - 1);
                    if (scroll_offset + 4 > filtered_count)
                        scroll_offset = filtered_count - 4;
                    if (scroll_offset < 0) scroll_offset = 0;
                }
            }

            bool should_move_up = false;
            if (kDown & KEY_UP) {
                should_move_up = true;
                repeat_delay = REPEAT_INITIAL_DELAY;
            } else if (kHeld & KEY_UP) {
                repeat_delay--;
                if (repeat_delay <= 0) { should_move_up = true; repeat_delay = REPEAT_SPEED; }
            }
            if (should_move_up) {
                if (selected_index > 0) {
                    selected_index--;
                    if (selected_index < scroll_offset + 1)
                        scroll_offset = selected_index - 1;
                    if (scroll_offset < 0) scroll_offset = 0;
                }
            }

            if (!(kHeld & KEY_DOWN) && !(kHeld & KEY_UP)) repeat_delay = 0;

            if ((kDown & KEY_A) && filtered_count > 0) {
                int real_idx = filtered_indices[selected_index];
                char filepath[256], clean_name[128];

                sanitize_filename(titles[real_idx].name, clean_name, sizeof(clean_name));
                const char* ext = (strcmp(titles[real_idx].platform, "GBA") == 0) ? ".gba" : ".nds";
                if (download_folder[0] != '\0') {
                    snprintf(filepath, sizeof(filepath), "sdmc:/%s/%s%s", download_folder, clean_name, ext);
                } else {
                    snprintf(filepath, sizeof(filepath), "sdmc:/%s%s", clean_name, ext);
                }

                long expected_size = titles[real_idx].size_mb * 1024L * 1024L;
                download_file_curl(titles[real_idx].url, filepath, expected_size, real_idx);
            }
            }
        }

        C2D_TextBufClear(dynamicBuf);
        icon_gpu_flush();
        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        anim_update();

        C2D_TargetClear(top_target, C2D_Color32(255, 255, 255, 255));
        C2D_SceneBegin(top_target);
        if (top_spritesheet) C2D_DrawSprite(&top_sprite);
        if (bags_top_sheet) anim_draw_bags(bags_top_sheet, bags_top, NUM_BAGS_TOP);
        if (app_state == STATE_GAMES)    display_ui();
        if (app_state == STATE_SETTINGS) display_settings();
        if (app_state == STATE_MANUAL)   display_manual();

        C2D_TargetClear(bottom_target, C2D_Color32(255, 255, 255, 255));
        C2D_SceneBegin(bottom_target);
        if (bottom_spritesheet) C2D_DrawSprite(&bottom_sprite);
        if (bags_bot_sheet) anim_draw_bags(bags_bot_sheet, bags_bot, NUM_BAGS_BOT);
        if      (app_state == STATE_MENU)  display_main_menu();
        else if (app_state == STATE_GAMES) display_ui_bottom();

        C3D_FrameEnd(0);
    }

cleanup:
    icon_system_free();
    if (audio_loaded) {
        ndspChnWaveBufClear(0);
        ndspExit();
        if (audioBuffer) linearFree(audioBuffer);
    }

    if (dynamicBuf)         C2D_TextBufDelete(dynamicBuf);
    if (top_spritesheet)    C2D_SpriteSheetFree(top_spritesheet);
    if (bottom_spritesheet) C2D_SpriteSheetFree(bottom_spritesheet);
    if (bags_top_sheet)     C2D_SpriteSheetFree(bags_top_sheet);
    if (bags_bot_sheet)     C2D_SpriteSheetFree(bags_bot_sheet);
    if (loupe_sheet)       C2D_SpriteSheetFree(loupe_sheet);
    if (gear_spritesheet)  C2D_SpriteSheetFree(gear_spritesheet);

    C2D_Fini();
    C3D_Fini();
    socExit();
    if (SOC_buffer) free(SOC_buffer);
    romfsExit();
    gfxExit();
    return 0;
}
